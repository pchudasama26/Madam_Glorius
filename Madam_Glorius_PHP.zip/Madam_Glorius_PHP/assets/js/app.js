const products = [
  {
    id: 1,
    name: "Elegant Black Block Heels",
    price: 1499,
    img: "assets/images/product-1.svg",
    category: "Heels",
  },
  {
    id: 2,
    name: "White Casual Sneakers",
    price: 1299,
    img: "assets/images/product-2.svg",
    category: "Sneakers",
  },
  {
    id: 3,
    name: "Beige Party Wear Heels",
    price: 1699,
    img: "assets/images/product-3.svg",
    category: "Heels",
  },
  {
    id: 4,
    name: "Pink Comfort Flats",
    price: 899,
    img: "assets/images/product-4.svg",
    category: "Flats",
  },
  {
    id: 5,
    name: "Golden Traditional Sandals",
    price: 1199,
    img: "assets/images/product-5.svg",
    category: "Sandals",
  },
  {
    id: 6,
    name: "Rose Casual Slippers",
    price: 699,
    img: "assets/images/product-6.svg",
    category: "Slippers",
  },
  {
    id: 7,
    name: "Brown Wedge Heels",
    price: 1399,
    img: "assets/images/product-7.svg",
    category: "Wedges",
  },
  {
    id: 8,
    name: "Red Party Heels",
    price: 1799,
    img: "assets/images/product-8.svg",
    category: "Heels",
  },
];

function getCart() {
  return JSON.parse(localStorage.getItem("mg_cart") || "[]");
}
function setCart(c) {
  localStorage.setItem("mg_cart", JSON.stringify(c));
  updateCount();
}
function addCart(id) {
  let c = getCart(),
    x = c.find((i) => i.id == id);
  x ? x.qty++ : c.push({ id, qty: 1, size: 7 });
  setCart(c);
  showToast("Product added to cart!");
}
function removeCart(id) {
  setCart(getCart().filter((i) => i.id != id));
  location.reload();
}
function updateCount() {
  let n = getCart().reduce((s, i) => s + i.qty, 0);
  document.querySelectorAll(".cart-count").forEach((x) => (x.textContent = n));
}
function money(n) {
  return "₹" + Number(n).toLocaleString("en-IN");
}

function showToast(message) {
  let toast = document.getElementById("mg-toast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "mg-toast";
    toast.className = "mg-toast";
    document.body.appendChild(toast);
  }
  toast.innerHTML =
    '<span><i class="bi bi-check-lg" aria-hidden="true"></i></span> ' + message;
  toast.classList.add("show");
  clearTimeout(window.mgToastTimer);
  window.mgToastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
}

function productCards(list = products) {
  return list
    .map(
      (p) => `
    <article class="card product-card">
        <span class="badge">NEW</span>
        <button class="wishlist-btn" type="button" aria-label="Add to wishlist" onclick="showToast('Wishlist feature added!')"><i class="bi bi-heart" aria-hidden="true"></i></button>
        <a class="product-image-wrap" href="product-details.php?id=${p.id}">
            <img src="${p.img}" alt="${p.name}" loading="lazy">
            <span class="quick-view">Quick View</span>
        </a>
        <div class="card-body">
            <small class="product-category">${p.category}</small>
            <h3>${p.name}</h3>
            <div class="rating-stars"><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i> <span>(12)</span></div>
            <div class="price">${money(p.price)} <span class="old">${money(p.price + 300)}</span></div>
            <div class="card-actions">
                <a class="btn btn-outline" href="product-details.php?id=${p.id}">VIEW</a>
                <button class="btn" onclick="addCart(${p.id})">ADD TO CART</button>
            </div>
        </div>
    </article>`,
    )
    .join("");
}

function filterProducts() {
  const input = document.querySelector("[data-product-search]");
  const grid = document.querySelector("[data-product-grid]");
  if (!input || !grid) return;
  const value = input.value.trim().toLowerCase();
  const filtered = products.filter(
    (p) =>
      p.name.toLowerCase().includes(value) ||
      p.category.toLowerCase().includes(value),
  );
  grid.innerHTML = filtered.length
    ? productCards(filtered)
    : '<div class="empty-search"><div><i class="bi bi-search" aria-hidden="true"></i></div><h3>No products found</h3><p>Try another product name or category.</p></div>';
  const count = document.querySelector("[data-product-count]");
  if (count) count.textContent = filtered.length + " Products";
}

document.addEventListener("DOMContentLoaded", () => {
  updateCount();
  // document.querySelectorAll("[data-product-grid]").forEach(el=>el.innerHTML=productCards());
  const input = document.querySelector("[data-product-search]");
  if (input) input.addEventListener("input", filterProducts);

  document.querySelectorAll(".search").forEach((form) => {
    form.addEventListener("submit", (e) => {
      const field = form.querySelector("input");
      if (field && field.value.trim()) {
        e.preventDefault();
        location.href =
          "shop.php?search=" + encodeURIComponent(field.value.trim());
      }
    });
  });
});
document.addEventListener("DOMContentLoaded", () => {
  const priceRange = document.getElementById("priceRange");
  const priceValue = document.getElementById("priceValue");

  if (priceRange && priceValue) {
    priceRange.addEventListener("input", () => {
      priceValue.textContent =
        "₹" + Number(priceRange.value).toLocaleString("en-IN");
    });
  }
});
