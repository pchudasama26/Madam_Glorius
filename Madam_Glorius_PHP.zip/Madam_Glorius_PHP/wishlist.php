<?php

$pageTitle = "Wishlist | Madam Glorious";

ob_start();

?>

<div class="page-head"><div class="container"><h1>My Wishlist</h1></div></div><section class="section"><div class="container"><div class="notice">Wishlist is a frontend demo. You can extend it using localStorage.</div><div class="grid" data-product-grid></div></div></section>

<?php

$content = ob_get_clean();

include 'layout.php';

?>
