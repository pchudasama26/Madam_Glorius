<?php

$pageTitle = "Login | Madam Glorious";

?>

<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?= $pageTitle ?></title>

    <!-- Bootstrap -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
        rel="stylesheet">

    <!-- Admin Login CSS -->
    <link
        href="assets/css/style.css"
        rel="stylesheet">

</head>

<body>

    <div class="login-page">

        <div class="login-card">

            <!-- Brand -->
            <div class="login-brand">
                Madam <span>Glorious</span>
            </div>

            <p class="text-center text-muted mb-4">
                Login to Your Account
            </p>


            <form id="loginForm">

                <!-- Email -->
                <div class="mb-3">

                    <label
                        for="email"
                        class="form-label">
                        Email
                    </label>

                    <input
                        type="email"
                        class="form-control"
                        id="email"
                        name="email"
                        placeholder="Enter your email"
                        required>

                </div>


                <!-- Password -->
                <div class="mb-3">

                    <label
                        for="password"
                        class="form-label">
                        Password
                    </label>

                    <input
                        type="password"
                        class="form-control"
                        id="password"
                        name="password"
                        placeholder="Enter your password"
                        required>

                </div>


                <!-- Remember + Forgot -->
                <div class="d-flex justify-content-between mb-4">

                    <div class="form-check">

                        <input
                            class="form-check-input"
                            type="checkbox"
                            id="remember">

                        <label
                            class="form-check-label"
                            for="remember">
                            Remember me
                        </label>

                    </div>

                    <a
                        href="#"
                        style="color:var(--mg-pink); text-decoration:none;">
                        Forgot password?
                    </a>

                </div>


                <!-- Login Button -->
                <button
                    type="submit"
                    class="btn btn-mg w-100 py-2">
                    Login
                </button>

            </form>

            <!-- Create New Account -->
            <div class="text-center mt-4">
                <p class="text-muted mb-0">
                    New customer?
                    <a href="register.php" class="register-login-link">Create New Account</a>
                </p>
            </div>

            <!-- Demo Credentials -->
            <div class="text-center mt-4">

                <p class="text-muted small mb-1">
                    Frontend Demo Login
                </p>

                <small class="text-muted">
                    Admin: admin@madamglorious.com / admin123
                </small>

                <br>

                <small class="text-muted">
                    User: user@madamglorious.com / user123
                </small>

            </div>

        </div>

    </div>


    <script>

        document.getElementById("loginForm").addEventListener("submit", function (e) {

            e.preventDefault();

            const email = document.getElementById("email").value.trim().toLowerCase();
            const password = document.getElementById("password").value;


            /* Admin Login */
            if (
                email === "admin@madamglorious.com" &&
                password === "admin123"
            ) {

                window.location.href = "admin/admin/dashboard.php";

            }


            /* User Login */
            else if (
                email === "user@madamglorious.com" &&
                password === "user123"
            ) {

                window.location.href = "dashboard.php";

            }


            /* Invalid Login */
            else {

                alert("Invalid email or password.");

            }

        });

    </script>

</body>

</html>