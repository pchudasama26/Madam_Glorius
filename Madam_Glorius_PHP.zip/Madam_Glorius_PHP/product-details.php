<?php

$pageTitle = "Product Details | Madam Glorious";

ob_start();

?>

<div class="page-head"><div class="container"><h1>Product Details</h1><div class="breadcrumb">Home / Shop / Product</div></div></div>
<section class="section"><div class="container" id="product-detail"></div></section>
<script>
document.addEventListener("DOMContentLoaded",()=>{const id=Number(new URLSearchParams(location.search).get("id")||1),p=products.find(x=>x.id===id)||products[0];
document.getElementById("product-detail").innerHTML=`<div class="product-layout"><div><img class="main-image" src="${p.img}" alt="${p.name}"><div class="thumbs"><img src="${p.img}"><img src="${p.img}"><img src="${p.img}"></div></div><div class="details"><h1>${p.name}</h1><div class="rating"><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i> <span style="color:#555">(24 Reviews)</span></div><h2 class="price">${money(p.price)} <span class="old">${money(p.price+300)}</span></h2><p>Designed for comfort and elegance. Perfect for parties, office wear and special occasions.</p><hr><b>SELECT SIZE</b><div class="sizes">${[5,6,7,8,9].map(x=>`<button onclick="document.querySelectorAll('.sizes button').forEach(b=>b.style.borderColor='#ddd');this.style.borderColor='#e63969'">${x}</button>`).join("")} <a href="#sizechart">Size Chart</a></div><br><b>SELECT COLOR</b><div class="colors"><button class="black"></button><button class="beige"></button><button class="pink"></button></div><br><b>QUANTITY</b><div class="qty"><button onclick="changeQty(-1)">−</button><span id="q">1</span><button onclick="changeQty(1)">+</button></div><div class="detail-actions"><button class="btn" onclick="addCart(p.id)"><i class="bi bi-cart-plus me-1" aria-hidden="true"></i> ADD TO CART</button><a class="btn btn-outline" href="checkout.php">BUY NOW</a></div><p><i class="bi bi-heart me-1" aria-hidden="true"></i> Add to Wishlist &nbsp;&nbsp; <i class="bi bi-arrow-left-right me-1" aria-hidden="true"></i> Compare &nbsp;&nbsp; <i class="bi bi-share me-1" aria-hidden="true"></i> Share</p></div></div><div class="section" id="sizechart"><h2>PRODUCT DESCRIPTION</h2><p><b>Material:</b> Synthetic Leather &nbsp; | &nbsp; <b>Heel Height:</b> 3 Inches &nbsp; | &nbsp; <b>Occasion:</b> Party, Office Wear, Casual</p><h3>Size Chart</h3><p>UK 5 = 24 cm &nbsp; | &nbsp; UK 6 = 25 cm &nbsp; | &nbsp; UK 7 = 26 cm &nbsp; | &nbsp; UK 8 = 27 cm &nbsp; | &nbsp; UK 9 = 28 cm</p></div>`;
window.changeQty=(n)=>{let q=document.getElementById("q");q.textContent=Math.max(1,+q.textContent+n)}})
</script>

<?php

$content = ob_get_clean();

include 'layout.php';

?>
