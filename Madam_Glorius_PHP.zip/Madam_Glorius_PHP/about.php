<?php

$pageTitle = "About Us | Madam Glorious";

ob_start();

?>

<div class="page-head"><div class="container"><h1>About Madam Glorious</h1><div class="breadcrumb">Home / About Us</div></div></div><section class="section"><div class="container" style="max-width:850px;text-align:center"><h2>Fashion Meets Comfort</h2><p>Madam Glorious is a ladies footwear brand created for women who want to feel confident, comfortable and stylish in every step.</p><p>Our collection includes heels, flats, sandals, sneakers, slippers and party footwear for different occasions.</p><div class="features"><div class="feature"><b>Our Mission</b>Quality footwear at accessible prices.</div><div class="feature"><b>Our Vision</b>To become a trusted ladies footwear brand.</div><div class="feature"><b>Our Promise</b>Style, comfort and customer satisfaction.</div></div></div></section>

<?php

$content = ob_get_clean();

include 'layout.php';

?>
