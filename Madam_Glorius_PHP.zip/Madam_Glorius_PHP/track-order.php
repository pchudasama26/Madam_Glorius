<?php

$pageTitle = "Track Order | Madam Glorious";

ob_start();

?>

<div class="page-head"><div class="container"><h1>Track Order</h1></div></div><section class="section"><div class="container" style="max-width:850px"><h2>Order #MG2026001</h2><p>Your demo order is on the way.</p><div class="order-status"><div class="status active"><i class="bi bi-check-circle-fill" aria-hidden="true"></i><br>Order Placed</div><div class="status active"><i class="bi bi-check-circle-fill" aria-hidden="true"></i><br>Confirmed</div><div class="status active"><i class="bi bi-check-circle-fill" aria-hidden="true"></i><br>Shipped</div><div class="status"><i class="bi bi-truck" aria-hidden="true"></i><br>Out for Delivery</div><div class="status"><i class="bi bi-check-circle-fill" aria-hidden="true"></i><br>Delivered</div></div></div></section>

<?php

$content = ob_get_clean();

include 'layout.php';

?>
