<?php

$pageTitle = "Contact Us | Madam Glorious";

ob_start();

?>

<div class="page-head">
    <div class="container">
        <h1>Contact Us</h1>

        <div class="breadcrumb">
            Home / Contact Us
        </div>
    </div>
</div>


<section class="section">
    <div class="container">

        <!-- Bootstrap Row -->
        <div class="row g-5 align-items-start">

            <!-- LEFT SIDE : CONTACT INFORMATION -->
            <div class="col-12 col-lg-5">

                <div class="contact-info">

                    <h2>Get In Touch</h2>

                    <p>
                        <span class="contact-icon"><i class="bi bi-geo-alt-fill" aria-hidden="true"></i></span>
                        Rajkot, Gujarat, India
                    </p>

                    <p>
                        <span class="contact-icon"><i class="bi bi-telephone-fill" aria-hidden="true"></i></span>
                        +91 98765 43210
                    </p>

                    <p>
                        <span class="contact-icon"><i class="bi bi-envelope-fill" aria-hidden="true"></i></span>
                        support@madamglorious.com
                    </p>

                    <p>
                        We would love to hear from you.
                    </p>

                </div>

            </div>


            <!-- RIGHT SIDE : CONTACT FORM -->
            <div class="col-12 col-lg-7">

                <div class="form-wrap w-100">

                    <form
                        id="contactForm"
                        onsubmit="event.preventDefault();"
                    >

                        <!-- Name -->
                        <div class="form-group">

                            <label for="name">
                                Name
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                name="name"
                                id="name"
                                placeholder="Enter your name"
                                data-validation="required alpha"
                            >

                            <span
                                class="error text-danger"
                                id="nameError">
                            </span>

                        </div>


                        <!-- Email -->
                        <div class="form-group">

                            <label for="contactEmail">
                                Email
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                name="contactEmail"
                                id="contactEmail"
                                placeholder="Enter your email"
                                data-validation="required email"
                            >

                            <span
                                class="error text-danger"
                                id="contactEmailError">
                            </span>

                        </div>


                        <!-- Subject -->
                        <div class="form-group">

                            <label for="subject">
                                Subject
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                name="subject"
                                id="subject"
                                placeholder="Enter subject"
                                data-validation="required"
                            >

                            <span
                                class="error text-danger"
                                id="subjectError">
                            </span>

                        </div>


                        <!-- Message -->
                        <div class="form-group">

                            <label for="message">
                                Message
                            </label>

                            <textarea
                                rows="5"
                                class="form-control"
                                name="message"
                                id="message"
                                placeholder="Enter your message"
                                data-validation="required"
                            ></textarea>

                            <span
                                class="error text-danger"
                                id="messageError">
                            </span>

                        </div>


                        <!-- Button -->
                        <div class="text-center mt-3">

                            <button
                                type="submit"
                                class="btn btn-auth">
                                SEND MESSAGE
                            </button>

                        </div>

                    </form>

                </div>

            </div>

        </div>

    </div>
</section>


<?php

$content = ob_get_clean();

include 'layout.php';

?>