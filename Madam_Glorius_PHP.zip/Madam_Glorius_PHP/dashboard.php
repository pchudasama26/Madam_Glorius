<?php
$pageTitle = "My Account | Madame Glorius";

$username = "xyz";
$email = "xyz@example.com";

$totalOrders = 12;
$wishlistItems = 8;
$rewardPoints = 250;

$orders = [
    [
        "id" => "#MG1025",
        "date" => "02 Sep 2026",
        "items" => "2 Items",
        "total" => 2499,
        "status" => "Delivered"
    ],
    [
        "id" => "#MG1024",
        "date" => "28 Aug 2026",
        "items" => "1 Item",
        "total" => 1799,
        "status" => "Processing"
    ],
    [
        "id" => "#MG1023",
        "date" => "20 Aug 2026",
        "items" => "3 Items",
        "total" => 3899,
        "status" => "Shipped"
    ],
    [
        "id" => "#MG1022",
        "date" => "15 Aug 2026",
        "items" => "1 Item",
        "total" => 1299,
        "status" => "Delivered"
    ]
];

ob_start();
?>

<section class="mg-dashboard">
    <div class="container">

        <!-- Dashboard Layout -->
        <div class="mg-dashboard-layout">

            <!-- Sidebar -->
            <aside class="mg-account-sidebar">

                <div class="mg-profile-summary">
                    <div class="mg-profile-icon">
                        <i class="bi bi-person"></i>
                    </div>

                    <h3><?= htmlspecialchars($username) ?></h3>
                    <p><?= htmlspecialchars($email) ?></p>
                </div>

                <nav class="mg-account-menu">

                    <a href="dashboard.php" class="mg-menu-link active">
                        <i class="bi bi-grid"></i>
                        <span>Dashboard</span>
                    </a>

                    <a href="order.php" class="mg-menu-link">
                        <i class="bi bi-bag"></i>
                        <span>My Orders</span>
                    </a>

                    <a href="profile.php" class="mg-menu-link">
                        <i class="bi bi-person"></i>
                        <span>My Profile</span>
                    </a>

                    <a href="wishlist.php" class="mg-menu-link">
                        <i class="bi bi-heart"></i>
                        <span>Wishlist</span>
                    </a>

                    <a href="addresses.php" class="mg-menu-link">
                        <i class="bi bi-geo-alt"></i>
                        <span>Addresses</span>
                    </a>

                    <a href="account_setitngs.php" class="mg-menu-link">
                        <i class="bi bi-gear"></i>
                        <span>Account Settings</span>
                    </a>

                    <a href="logout.php" class="mg-menu-link mg-logout">
                        <i class="bi bi-box-arrow-right"></i>
                        <span>Logout</span>
                    </a>

                </nav>
            </aside>

            <!-- Main Content -->
            <main class="mg-dashboard-main">

                <!-- Page Heading -->
                <div class="mg-dashboard-heading">
                    <h1>Hello!</h1>
                    <p>Here's a quick overview of your account.</p>
                </div>

                <!-- Statistics Cards -->
                <div class="mg-stats-grid">

                    <div class="mg-stat-card">
                        <div class="mg-stat-icon">
                            <i class="bi bi-bag"></i>
                        </div>
                        <h2><?= $totalOrders ?></h2>
                        <p>Total Orders</p>
                    </div>

                    <div class="mg-stat-card">
                        <div class="mg-stat-icon">
                            <i class="bi bi-heart"></i>
                        </div>
                        <h2><?= $wishlistItems ?></h2>
                        <p>Wishlist Items</p>
                    </div>

                    <div class="mg-stat-card">
                        <div class="mg-stat-icon">
                            <i class="bi bi-gift"></i>
                        </div>
                        <h2><?= $rewardPoints ?></h2>
                        <p>Reward Points</p>
                    </div>

                </div>

                <!-- Recent Orders -->
                <section class="mg-recent-orders">

                    <div class="mg-orders-heading">
                        <h2>Recent Orders</h2>
                        <a href="order.php">View All</a>
                    </div>

                    <div class="table-responsive">
                        <table class="mg-orders-table">

                            <thead>
                                <tr>
                                    <th>ORDER</th>
                                    <th>DATE</th>
                                    <th>ITEMS</th>
                                    <th>TOTAL</th>
                                    <th>STATUS</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php foreach ($orders as $order): ?>
                                    <tr>
                                        <td>
                                            <a href="order.php">
                                                <?= htmlspecialchars($order["id"]) ?>
                                            </a>
                                        </td>

                                        <td>
                                            <?= htmlspecialchars($order["date"]) ?>
                                        </td>

                                        <td>
                                            <?= htmlspecialchars($order["items"]) ?>
                                        </td>

                                        <td>
                                            ₹<?= number_format($order["total"]) ?>
                                        </td>

                                        <td>
                                            <span class="mg-order-status status-<?= strtolower($order["status"]) ?>">
                                                <?= htmlspecialchars($order["status"]) ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>

                        </table>
                    </div>

                </section>

            </main>
        </div>
    </div>
</section>

<?php
$content = ob_get_clean();
include "layout.php";
?>