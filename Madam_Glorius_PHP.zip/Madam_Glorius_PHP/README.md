# Madam Glorious - Ladies Footwear E-Commerce Frontend

## Technologies
- HTML5
- CSS3
- JavaScript
- LocalStorage for demo cart

## Pages
Home, Shop, Product Details, About Us, Contact Us, Login, Register,
Cart, Wishlist, Checkout, Track Order.

## How to run
Open `index.html` in a web browser.

This is frontend-only. No PHP, database, or payment gateway is included.


## Stylish PHP Version
All frontend pages have been converted from `.html` to `.php`. Existing brand colors are preserved. Styling upgrades include hover animations, modern cards, rounded buttons, improved search, responsive spacing, product quick-view hover, wishlist buttons, and toast notifications. Default product images are included in `assets/images/`.
