<?php
session_start();

$pageTitle = "Cart | Madame Glorious";

ob_start();
?>

<!-- PAGE TITLE -->
<section class="page-head">
    <div class="container">
        <h1>My Cart</h1>
        <div class="breadcrumb justify-content-center">
            <a href="index.php">Home</a> &nbsp;/&nbsp; <span>Cart</span>
        </div>
    </div>
</section>

<!-- CART SECTION -->
<section class="section">
    <div class="container" id="cart-area">
        <!-- JavaScript Will Render Cart Items Here -->
    </div>
</section>

<script>
    document.addEventListener("DOMContentLoaded", () => {
        let cart = getCart();
        let area = document.getElementById("cart-area");

        // 1. Check if Cart is Empty
        if (!cart || !cart.length) {
            area.innerHTML = `
            <div class="empty-search text-center py-5">
                <div class="mb-3"><i class="bi bi-bag-x fs-1 text-pink"></i></div>
                <h3 class="font-serif">Your cart is currently empty</h3>
                <p class="text-muted mb-4">Looks like you haven't added any items to your cart yet.</p>
                <a class="btn px-4" href="shop.php">CONTINUE SHOPPING</a>
            </div>
        `;
            return;
        }

        // 2. Render Cart Items & Summary
        let subtotal = 0;

        let itemsHTML = cart.map(item => {
            // Fallback for item price and details
            let itemPrice = item.price || 0;
            let lineTotal = itemPrice * item.qty;
            subtotal += lineTotal;

            return `
            <div class="cart-row d-flex align-items-center justify-content-between p-3 mb-3 border rounded shadow-sm bg-white">
                <div class="d-flex align-items-center gap-3">
                    <img src="${item.img || 'https://via.placeholder.com/80'}" alt="${item.name}" style="width: 80px; height: 80px; object-fit: cover;" class="rounded">
                    <div>
                        <h5 class="m-0 font-serif fs-6">${item.name}</h5>
                        ${item.size ? `<small class="text-muted">Size: ${item.size}</small>` : ''}
                        <div class="fw-bold text-pink mt-1">${money(itemPrice)}</div>
                    </div>
                </div>

                <div class="qty d-flex align-items-center border rounded">
                    <button class="btn btn-sm btn-light border-0" onclick="updateQty(${item.id}, -1)">−</button>
                    <span class="px-3 fw-bold">${item.qty}</span>
                    <button class="btn btn-sm btn-light border-0" onclick="updateQty(${item.id}, 1)">+</button>
                </div>

                <div class="fw-bold fs-6">
                    ${money(lineTotal)}
                </div>

                <button class="btn btn-sm btn-outline-danger border-0" onclick="removeItem(${item.id})" title="Remove">
                    <i class="bi bi-trash fs-5"></i>
                </button>
            </div>
        `;
        }).join("");

        // 3. Complete Cart Layout Output
        area.innerHTML = `
        <div class="row g-4">
            <div class="col-lg-8">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="font-serif m-0">Shopping Cart (${cart.length} Items)</h4>
                </div>
                ${itemsHTML}
            </div>

            <div class="col-lg-4">
                <div class="summary border p-4 rounded shadow-sm bg-white">
                    <h3 class="fs-4 font-serif border-bottom pb-2 mb-3">Order Summary</h3>
                    
                    <div class="d-flex justify-content-between my-2">
                        <span class="text-muted">Subtotal</span>
                        <span class="fw-bold">${money(subtotal)}</span>
                    </div>
                    
                    <div class="d-flex justify-content-between my-2">
                        <span class="text-muted">Shipping</span>
                        <span class="text-success fw-bold">FREE</span>
                    </div>
                    
                    <hr>
                    
                    <div class="d-flex justify-content-between my-2 fw-bold fs-5">
                        <span>Total Amount</span>
                        <span class="text-pink">${money(subtotal)}</span>
                    </div>

                    <a href="checkout.php" class="btn w-100 mt-3 py-2 text-center">PROCEED TO CHECKOUT</a>
                    <a href="shop.php" class="btn btn-outline w-100 mt-2 py-2 text-center">CONTINUE SHOPPING</a>
                </div>
            </div>
        </div>
    `;

        // Global Functions for Qty & Remove
        window.updateQty = (id, change) => {
            let currentCart = getCart();
            let product = currentCart.find(i => i.id === id);
            if (product) {
                product.qty = Math.max(1, product.qty + change);
                setCart(currentCart);
                location.reload();
            }
        };

        window.removeItem = (id) => {
            let currentCart = getCart();
            let updatedCart = currentCart.filter(i => i.id !== id);
            setCart(updatedCart);
            location.reload();
        };
    });
</script>

<?php
$content = ob_get_clean();
include 'layout.php';
?>