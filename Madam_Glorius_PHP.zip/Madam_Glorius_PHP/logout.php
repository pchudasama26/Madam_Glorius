<?php
session_start();

// Real logout (when the user confirms via ?confirm=1)
$loggedOut = false;
if (isset($_GET['confirm']) && $_GET['confirm'] === '1') {
    $_SESSION = [];
    session_destroy();
    $loggedOut = true;
}

$pageTitle = "Logout | Madam Glorious";

ob_start();
?>

<!-- Page Header -->
<section class="page-head">
    <div class="container">
        <h1>Logout</h1>
        <div class="breadcrumb">
            <a href="index.php">Home</a> / Logout
        </div>
    </div>
</section>

<!-- Logout Content -->
<section class="section">
    <div class="container">
        <div class="form-wrap text-center">

            <?php if (!$loggedOut): ?>

                <div style="font-size:52px; color:var(--pink);">
                    <i class="bi bi-box-arrow-right"></i>
                </div>

                <h2 class="section-title">Leaving so soon?</h2>

                <p style="color:var(--muted); margin-bottom:25px;">
                    Are you sure you want to logout from your Madam Glorious account?
                </p>

                <div class="detail-actions">
                    <a href="logout.php?confirm=1" class="btn">
                        <i class="bi bi-box-arrow-right"></i> YES, LOGOUT
                    </a>
                    <a href="index.php" class="btn btn-outline">
                        STAY LOGGED IN
                    </a>
                </div>

            <?php else: ?>

                <div style="font-size:52px; color:var(--pink);">
                    <i class="bi bi-check-circle"></i>
                </div>

                <h2 class="section-title">You've been logged out</h2>

                <div class="notice">
                    Thank you for visiting! Redirecting to login page in
                    <b id="logoutTimer">5</b> seconds...
                </div>

                <div class="detail-actions">
                    <a href="login.php" class="btn">LOGIN AGAIN</a>
                    <a href="shop.php" class="btn btn-outline">CONTINUE SHOPPING</a>
                </div>

                <script>
                    // Uses showToast() from app.js
                    document.addEventListener("DOMContentLoaded", function () {
                        showToast("Logged out successfully!");

                        // Clear saved login info (cart is kept)
                        localStorage.removeItem("mg_user");

                        let seconds = 5;
                        const timer = document.getElementById("logoutTimer");
                        const interval = setInterval(function () {
                            seconds--;
                            timer.textContent = seconds;
                            if (seconds <= 0) {
                                clearInterval(interval);
                                location.href = "login.php";
                            }
                        }, 1000);
                    });
                </script>

            <?php endif; ?>

        </div>
    </div>
</section>

<?php
$content = ob_get_clean();

// Your layout file (the one with the header, $content and footer)
include 'layout.php';