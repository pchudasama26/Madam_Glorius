<?php
session_start();

$pageTitle = "My Profile | Madame Glorious";

if (!isset($_SESSION['profile'])) {
    $_SESSION['profile'] = [
        'first_name' => 'Madam',
        'last_name' => 'Glorious',
        'email' => 'customer@example.com',
        'phone' => '9876543210',
        'dob' => '',
        'gender' => 'Female',
        'member' => 'January 2026',
    ];
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['profile']['first_name'] = trim($_POST['first_name'] ?? '');
    $_SESSION['profile']['last_name'] = trim($_POST['last_name'] ?? '');
    $_SESSION['profile']['email'] = trim($_POST['email'] ?? '');
    $_SESSION['profile']['phone'] = trim($_POST['phone'] ?? '');
    $_SESSION['profile']['dob'] = trim($_POST['dob'] ?? '');
    $_SESSION['profile']['gender'] = trim($_POST['gender'] ?? '');
    $message = 'Profile saved successfully.';
}

$profile = $_SESSION['profile'];

function profileEscape($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

ob_start();
?>

<!-- PAGE TITLE -->
<section class="page-head">
    <div class="container">
        <h1>My Profile</h1>
        <p class="text-muted m-0">Manage your personal information and account details.</p>
    </div>
</section>

<section class="section mg-dashboard">
    <div class="container">
        <div class="mg-dashboard-layout">

            <!-- SIDEBAR -->
            <aside class="mg-account-sidebar">
                <div class="mg-profile-summary">
                    <div class="mg-profile-icon">
                        <i class="bi bi-person"></i>
                    </div>
                    <h3><?= profileEscape(trim($profile['first_name'] . ' ' . $profile['last_name'])) ?></h3>
                    <p><?= profileEscape($profile['email']) ?></p>
                </div>

                <nav class="mg-account-menu">
                    <a href="dashboard.php" class="mg-menu-link">
                        <i class="bi bi-grid"></i> <span>Dashboard</span>
                    </a>
                    <a href="order.php" class="mg-menu-link">
                        <i class="bi bi-bag"></i> <span>My Orders</span>
                    </a>
                    <a href="profile.php" class="mg-menu-link active">
                        <i class="bi bi-person"></i> <span>My Profile</span>
                    </a>
                    <a href="wishlist.php" class="mg-menu-link">
                        <i class="bi bi-heart"></i> <span>Wishlist</span>
                    </a>
                    <a href="addresses.php" class="mg-menu-link">
                        <i class="bi bi-geo-alt"></i> <span>Addresses</span>
                    </a>
                    <a href="account_setitngs.php" class="mg-menu-link">
                        <i class="bi bi-gear"></i> <span>Account Settings</span>
                    </a>
                    <a href="logout.php" class="mg-menu-link mg-logout">
                        <i class="bi bi-box-arrow-right"></i> <span>Logout</span>
                    </a>
                </nav>
            </aside>

            <!-- MAIN FORM CONTENT -->
            <div class="mg-dashboard-main">

                <?php if ($message !== ''): ?>
                    <div class="notice mb-4"><?= profileEscape($message) ?></div>
                <?php endif; ?>

                <!-- PERSONAL INFO -->
                <div class="form-wrap w-100 max-width-none mb-5">
                    <div class="border-bottom pb-2 mb-4">
                        <h3 class="fs-4 font-serif m-0">Personal Information</h3>
                        <small class="text-muted">Update your personal details below.</small>
                    </div>

                    <form method="post" action="profile.php">
                        <div class="two-col">
                            <div class="form-group">
                                <label for="first_name">First Name</label>
                                <input type="text" id="first_name" name="first_name" class="form-control"
                                    value="<?= profileEscape($profile['first_name']) ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="last_name">Last Name</label>
                                <input type="text" id="last_name" name="last_name" class="form-control"
                                    value="<?= profileEscape($profile['last_name']) ?>" required>
                            </div>
                        </div>

                        <div class="two-col">
                            <div class="form-group">
                                <label for="email">Email Address</label>
                                <input type="email" id="email" name="email" class="form-control"
                                    value="<?= profileEscape($profile['email']) ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="phone">Phone Number</label>
                                <input type="tel" id="phone" name="phone" class="form-control" maxlength="10"
                                    value="<?= profileEscape($profile['phone']) ?>" pattern="[0-9]{10}" required>
                            </div>
                        </div>

                        <div class="two-col">
                            <div class="form-group">
                                <label for="dob">Date of Birth</label>
                                <input type="date" id="dob" name="dob" class="form-control"
                                    value="<?= profileEscape($profile['dob']) ?>">
                            </div>
                            <div class="form-group">
                                <label for="gender">Gender</label>
                                <select id="gender" name="gender" class="form-select">
                                    <option value="">Select gender</option>
                                    <?php foreach (['Female', 'Male', 'Other'] as $gender): ?>
                                        <option value="<?= profileEscape($gender) ?>" <?= $profile['gender'] === $gender ? 'selected' : '' ?>>
                                            <?= profileEscape($gender) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="card-actions mt-4">
                            <button type="submit" class="btn px-4">SAVE CHANGES</button>
                            <a class="btn btn-outline ms-2 px-4" href="profile.php">CANCEL</a>
                        </div>
                    </form>
                </div>

                <!-- ACCOUNT DETAILS SUMMARY -->
                <div class="form-wrap w-100 max-width-none mb-5">
                    <div class="border-bottom pb-2 mb-3">
                        <h3 class="fs-4 font-serif m-0">Account Information</h3>
                    </div>
                    <p class="mb-2"><i class="bi bi-envelope text-pink me-2"></i> <strong>Email Address:</strong>
                        <?= profileEscape($profile['email']) ?>
                    </p>
                    <p class="mb-2"><i class="bi bi-telephone text-pink me-2"></i> <strong>Phone Number:</strong> +91
                        <?= profileEscape($profile['phone']) ?>
                    </p>
                    <p class="mb-0"><i class="bi bi-calendar text-pink me-2"></i> <strong>Member Since:</strong>
                        <?= profileEscape($profile['member']) ?>
                    </p>
                </div>

                <!-- SECURITY -->
                <div class="form-wrap w-100 max-width-none">
                    <div class="border-bottom pb-2 mb-3">
                        <h3 class="fs-4 font-serif m-0">Security</h3>
                    </div>
                    <p class="text-muted fs-6 mb-3">Keep your account secure by updating your password regularly.</p>
                    <a class="btn btn-outline" href="change-password.php">
                        <i class="bi bi-lock"></i> CHANGE PASSWORD
                    </a>
                </div>

            </div>
        </div>
    </div>
</section>

<?php
$content = ob_get_clean();
include 'layout.php';
?>