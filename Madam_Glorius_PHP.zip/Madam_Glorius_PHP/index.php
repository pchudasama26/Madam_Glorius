<?php

$pageTitle = "Home | Madam Glorious";

ob_start();

?>

<!-- ================= HERO SLIDER ================= -->

<section class="hero-slider">

    <div id="homeSlider" class="carousel slide" data-bs-ride="carousel">

        <!-- Slider Indicators -->
        <div class="carousel-indicators">

            <button type="button" data-bs-target="#homeSlider" data-bs-slide-to="0" class="active" aria-current="true"
                aria-label="Slide 1">
            </button>

            <button type="button" data-bs-target="#homeSlider" data-bs-slide-to="1" aria-label="Slide 2">
            </button>

            <button type="button" data-bs-target="#homeSlider" data-bs-slide-to="2" aria-label="Slide 3">
            </button>

        </div>

        <!-- Slider Images -->
        <div class="carousel-inner">

            <!-- Slide 1 -->
            <div class="carousel-item active">

                <img src="assets/images/hero.svg" class="d-block w-100" alt="Madam Glorious Collection">

                <div class="carousel-caption hero-caption">

                    <div class="eyebrow">
                        STEP INTO
                    </div>

                    <h1>
                        STYLE
                    </h1>

                    <p>
                        NEW COLLECTION<br>
                        FOR EVERY WOMAN
                    </p>

                    <a href="shop.php" class="btn hero-btn">
                        SHOP NOW
                    </a>

                </div>

            </div>

            <!-- Slide 2 -->
            <div class="carousel-item">

                <img src="assets/images/product-1.svg" class="d-block w-100" alt="Ladies Footwear">

                <div class="carousel-caption hero-caption">

                    <div class="eyebrow">
                        NEW ARRIVALS
                    </div>

                    <h1>
                        ELEGANCE
                    </h1>

                    <p>
                        BEAUTIFUL FOOTWEAR<br>
                        FOR EVERY OCCASION
                    </p>

                    <a href="shop.php" class="btn hero-btn">
                        EXPLORE NOW
                    </a>

                </div>

            </div>

            <!-- Slide 3 -->
            <div class="carousel-item">

                <img src="assets/images/product-3.svg" class="d-block w-100" alt="Ladies Shoes">

                <div class="carousel-caption hero-caption">

                    <div class="eyebrow">
                        SPECIAL COLLECTION
                    </div>

                    <h1>
                        GLAMOUR
                    </h1>

                    <p>
                        STEP UP YOUR STYLE<br>
                        WITH MADAM GLORIOUS
                    </p>

                    <a href="shop.php" class="btn hero-btn">
                        SHOP NOW
                    </a>

                </div>

            </div>

        </div>

        <!-- Previous Button -->
        <button class="carousel-control-prev" type="button" data-bs-target="#homeSlider" data-bs-slide="prev">

            <span class="carousel-control-prev-icon" aria-hidden="true">
            </span>

            <span class="visually-hidden">
                Previous
            </span>

        </button>

        <!-- Next Button -->
        <button class="carousel-control-next" type="button" data-bs-target="#homeSlider" data-bs-slide="next">

            <span class="carousel-control-next-icon" aria-hidden="true">
            </span>

            <span class="visually-hidden">
                Next
            </span>

        </button>

    </div>

</section>


<!-- ================= FEATURES ================= -->

<section class="features-section">

    <div class="container">

        <div class="row g-3 features">

            <!-- Feature 1 -->
            <div class="col-12 col-md-4">

                <div class="feature h-100 text-center">

                    <b>
                        FREE SHIPPING
                    </b>

                    <span>
                        On all orders above ₹999
                    </span>

                </div>

            </div>


            <!-- Feature 2 -->
            <div class="col-12 col-md-4">

                <div class="feature h-100 text-center">

                    <b>
                        EASY RETURNS
                    </b>

                    <span>
                        10 days return policy
                    </span>

                </div>

            </div>


            <!-- Feature 3 -->
            <div class="col-12 col-md-4">

                <div class="feature h-100 text-center">

                    <b>
                        SECURE PAYMENT
                    </b>

                    <span>
                        100% secure payment
                    </span>

                </div>

            </div>

        </div>

    </div>

</section>


<!-- ================= SHOP BY CATEGORY ================= -->

<section class="section">

    <div class="container">

        <h2 class="section-title">
            SHOP BY CATEGORY
        </h2>

        <div class="categories">

            <a class="category" href="shop.php">
                <br>
                Heels
            </a>

            <a class="category" href="shop.php">
                <br>
                Flats
            </a>

            <a class="category" href="shop.php">
                <br>
                Sandals
            </a>

            <a class="category" href="shop.php">
                <br>
                Sneakers
            </a>

            <a class="category" href="shop.php">
                <br>
                Slippers
            </a>

            <a class="category" href="shop.php">
                <br>
                Party Wear
            </a>

        </div>

    </div>

</section>


<!-- ================= NEW ARRIVALS ================= -->


<section class="section" style="background:#fff7f8">

    <div class="container">

        <h2 class="section-title">
            NEW ARRIVALS
        </h2>

        <div class="row g-4">

            <!-- Product 1 -->
            <div class="col-12 col-sm-6 col-md-4 col-lg-3">

                <article class="card product-card">

                    <span class="badge">NEW</span>

                    <button class="wishlist-btn" type="button" aria-label="Add to wishlist">
                        <i class="bi bi-heart" aria-hidden="true"></i>
                    </button>

                    <a class="product-image-wrap" href="product-details.php?id=1">

                        <img src="assets/images/product-1.png" alt="Elegant Black Block Heels" loading="lazy">

                        <span class="quick-view">
                            Quick View
                        </span>

                    </a>

                    <div class="card-body">

                        <small class="product-category">
                            Heels
                        </small>

                        <h3>
                            Elegant Black Block Heels
                        </h3>

                        <div class="rating-stars">
                            <i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill"
                                aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i
                                class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill"
                                aria-hidden="true"></i> <span>(12)</span>
                        </div>

                        <div class="price">
                            ₹1,499
                            <span class="old">
                                ₹1,799
                            </span>
                        </div>

                        <div class="card-actions">

                            <a class="btn btn-outline" href="product-details.php?id=1">
                                VIEW
                            </a>

                            <button class="btn" type="button">
                                ADD TO CART
                            </button>

                        </div>

                    </div>

                </article>

            </div>


            <!-- Product 2 -->
            <div class="col-12 col-sm-6 col-md-4 col-lg-3">

                <article class="card product-card">

                    <span class="badge">NEW</span>

                    <button class="wishlist-btn" type="button" aria-label="Add to wishlist">
                        <i class="bi bi-heart" aria-hidden="true"></i>
                    </button>

                    <a class="product-image-wrap" href="product-details.php?id=2">

                        <img src="assets/images/product-2.png" alt="White Casual Sneakers" loading="lazy">

                        <span class="quick-view">
                            Quick View
                        </span>

                    </a>

                    <div class="card-body">

                        <small class="product-category">
                            Sneakers
                        </small>

                        <h3>
                            White Casual Sneakers
                        </h3>

                        <div class="rating-stars">
                            <i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill"
                                aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i
                                class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill"
                                aria-hidden="true"></i> <span>(12)</span>
                        </div>

                        <div class="price">
                            ₹1,299
                            <span class="old">
                                ₹1,599
                            </span>
                        </div>

                        <div class="card-actions">

                            <a class="btn btn-outline" href="product-details.php?id=2">
                                VIEW
                            </a>

                            <button class="btn" type="button">
                                ADD TO CART
                            </button>

                        </div>

                    </div>

                </article>

            </div>


            <!-- Product 3 -->
            <div class="col-12 col-sm-6 col-md-4 col-lg-3">

                <article class="card product-card">

                    <span class="badge">NEW</span>

                    <button class="wishlist-btn" type="button" aria-label="Add to wishlist">
                        <i class="bi bi-heart" aria-hidden="true"></i>
                    </button>

                    <a class="product-image-wrap" href="product-details.php?id=3">

                        <img src="assets/images/product-9.png" alt="Beige Party Wear Heels" loading="lazy">

                        <span class="quick-view">
                            Quick View
                        </span>

                    </a>

                    <div class="card-body">

                        <small class="product-category">
                            Heels
                        </small>

                        <h3>
                            Beige Party Wear Heels
                        </h3>

                        <div class="rating-stars">
                            <i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill"
                                aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i
                                class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill"
                                aria-hidden="true"></i> <span>(12)</span>
                        </div>

                        <div class="price">
                            ₹1,699
                            <span class="old">
                                ₹1,999
                            </span>
                        </div>

                        <div class="card-actions">

                            <a class="btn btn-outline" href="product-details.php?id=3">
                                VIEW
                            </a>

                            <button class="btn" type="button">
                                ADD TO CART
                            </button>

                        </div>

                    </div>

                </article>

            </div>


            <!-- Product 4 -->
            <div class="col-12 col-sm-6 col-md-4 col-lg-3">

                <article class="card product-card">

                    <span class="badge">NEW</span>

                    <button class="wishlist-btn" type="button" aria-label="Add to wishlist">
                        <i class="bi bi-heart" aria-hidden="true"></i>
                    </button>

                    <a class="product-image-wrap" href="product-details.php?id=4">

                        <img src="assets/images/product-4.png" alt="Pink Comfort Flats" loading="lazy">

                        <span class="quick-view">
                            Quick View
                        </span>

                    </a>

                    <div class="card-body">

                        <small class="product-category">
                            Flats
                        </small>

                        <h3>
                            Pink Comfort Flats
                        </h3>

                        <div class="rating-stars">
                            <i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill"
                                aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i
                                class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill"
                                aria-hidden="true"></i> <span>(12)</span>
                        </div>

                        <div class="price">
                            ₹899
                            <span class="old">
                                ₹1,199
                            </span>
                        </div>

                        <div class="card-actions">

                            <a class="btn btn-outline" href="product-details.php?id=4">
                                VIEW
                            </a>

                            <button class="btn" type="button">
                                ADD TO CART
                            </button>

                        </div>

                    </div>

                </article>

            </div>


            <!-- Product 5 -->
            <div class="col-12 col-sm-6 col-md-4 col-lg-3">

                <article class="card product-card">

                    <span class="badge">NEW</span>

                    <button class="wishlist-btn" type="button" aria-label="Add to wishlist">
                        <i class="bi bi-heart" aria-hidden="true"></i>
                    </button>

                    <a class="product-image-wrap" href="product-details.php?id=5">

                        <img src="assets/images/product-5.png" alt="Golden Traditional Sandals" loading="lazy">

                        <span class="quick-view">
                            Quick View
                        </span>

                    </a>

                    <div class="card-body">

                        <small class="product-category">
                            Sandals
                        </small>

                        <h3>
                            Golden Traditional Sandals
                        </h3>

                        <div class="rating-stars">
                            <i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill"
                                aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i
                                class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill"
                                aria-hidden="true"></i> <span>(12)</span>
                        </div>

                        <div class="price">
                            ₹1,199
                            <span class="old">
                                ₹1,499
                            </span>
                        </div>

                        <div class="card-actions">

                            <a class="btn btn-outline" href="product-details.php?id=5">
                                VIEW
                            </a>

                            <button class="btn" type="button">
                                ADD TO CART
                            </button>

                        </div>

                    </div>

                </article>

            </div>


            <!-- Product 6 -->
            <div class="col-12 col-sm-6 col-md-4 col-lg-3">

                <article class="card product-card">

                    <span class="badge">NEW</span>

                    <button class="wishlist-btn" type="button" aria-label="Add to wishlist">
                        <i class="bi bi-heart" aria-hidden="true"></i>
                    </button>

                    <a class="product-image-wrap" href="product-details.php?id=6">

                        <img src="assets/images/product-6.png" alt="Rose Casual Slippers" loading="lazy">

                        <span class="quick-view">
                            Quick View
                        </span>

                    </a>

                    <div class="card-body">

                        <small class="product-category">
                            Slippers
                        </small>

                        <h3>
                            Rose Casual Slippers
                        </h3>

                        <div class="rating-stars">
                            <i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill"
                                aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i
                                class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill"
                                aria-hidden="true"></i> <span>(12)</span>
                        </div>

                        <div class="price">
                            ₹699
                            <span class="old">
                                ₹999
                            </span>
                        </div>

                        <div class="card-actions">

                            <a class="btn btn-outline" href="product-details.php?id=6">
                                VIEW
                            </a>

                            <button class="btn" type="button">
                                ADD TO CART
                            </button>

                        </div>

                    </div>

                </article>

            </div>


            <!-- Product 7 -->
            <div class="col-12 col-sm-6 col-md-4 col-lg-3">

                <article class="card product-card">

                    <span class="badge">NEW</span>

                    <button class="wishlist-btn" type="button" aria-label="Add to wishlist">
                        <i class="bi bi-heart" aria-hidden="true"></i>
                    </button>

                    <a class="product-image-wrap" href="product-details.php?id=7">

                        <img src="assets/images/product-11.png" alt="Brown Wedge Heels" loading="lazy">

                        <span class="quick-view">
                            Quick View
                        </span>

                    </a>

                    <div class="card-body">

                        <small class="product-category">
                            Wedges
                        </small>

                        <h3>
                            Brown Wedge Heels
                        </h3>

                        <div class="rating-stars">
                            <i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill"
                                aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i
                                class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill"
                                aria-hidden="true"></i> <span>(12)</span>
                        </div>

                        <div class="price">
                            ₹1,399
                            <span class="old">
                                ₹1,699
                            </span>
                        </div>

                        <div class="card-actions">

                            <a class="btn btn-outline" href="product-details.php?id=7">
                                VIEW
                            </a>

                            <button class="btn" type="button">
                                ADD TO CART
                            </button>

                        </div>

                    </div>

                </article>

            </div>


            <!-- Product 8 -->
            <div class="col-12 col-sm-6 col-md-4 col-lg-3">

                <article class="card product-card">

                    <span class="badge">NEW</span>

                    <button class="wishlist-btn" type="button" aria-label="Add to wishlist">
                        <i class="bi bi-heart" aria-hidden="true"></i>
                    </button>

                    <a class="product-image-wrap" href="product-details.php?id=8">

                        <img src="assets/images/product-12.png" alt="Red Party Heels" loading="lazy">

                        <span class="quick-view">
                            Quick View
                        </span>

                    </a>

                    <div class="card-body">

                        <small class="product-category">
                            Heels
                        </small>

                        <h3>
                            Red Party Heels
                        </h3>

                        <div class="rating-stars">
                            <i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill"
                                aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i
                                class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill"
                                aria-hidden="true"></i> <span>(12)</span>
                        </div>

                        <div class="price">
                            ₹1,799
                            <span class="old">
                                ₹2,099
                            </span>
                        </div>

                        <div class="card-actions">

                            <a class="btn btn-outline" href="product-details.php?id=8">
                                VIEW
                            </a>

                            <button class="btn" type="button">
                                ADD TO CART
                            </button>

                        </div>

                    </div>

                </article>

            </div>

        </div>

    </div>

</section>


<?php

$content = ob_get_clean();

include 'layout.php';

?>