<?php
$pageTitle = $pageTitle ?? "Madam Glorious";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo htmlspecialchars($pageTitle); ?></title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/bootstrap/bootstrap.min.css">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

    <!-- Top Bar -->
    <div class="topbar">
        <div class="container">
            <span>FREE SHIPPING on orders above ₹999</span>

            <span>
                Track Order &nbsp; | &nbsp;
                <a href="wishlist.php" class="top-wishlist">
                    <i class="bi bi-heart"></i>
                    Wishlist
                </a>
                &nbsp; | &nbsp;
                My Account
            </span>
        </div>
    </div>

    <!-- Header -->
    <header class="header">
        <div class="container header-row">

            <a href="index.php" class="logo">
                Madam<br>
                <span>Glorious</span>
            </a>

            <form class="search" onsubmit="event.preventDefault(); location.href='shop.php'">

                <div class="input-group stylish-search">

                    <input type="text" class="form-control" placeholder="Search for products..."
                        aria-label="Search for products">

                    <button class="btn search-btn" type="submit">

                        <i class="bi bi-search"></i>

                    </button>

                </div>
            </form>

            <div class="header-links">

                <a href="login.php" class="btn account-btn">
                    <i class="bi bi-person"></i>
                    <span>Login / Register</span>
                </a>

                <a href="cart.php" class="btn cart-btn">
                    <i class="bi bi-cart3"></i>
                    <span>My Cart</span>
                    <span class="cart-count">0</span>
                </a>
            </div>

        </div>
    </header>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg mg-navbar">

        <div class="container">

            <a class="navbar-brand d-lg-none" href="index.php">
                Madam <span>Glorious</span>
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar"
                aria-controls="mainNavbar" aria-expanded="false" aria-label="Toggle navigation">

                <i class="bi bi-list"></i>

            </button>

            <div class="collapse navbar-collapse" id="mainNavbar">

                <ul class="navbar-nav mx-auto">

                    <li class="nav-item">
                        <a class="nav-link" href="index.php">
                            HOME
                        </a>
                    </li>


                    <li class="nav-item">
                        <a class="nav-link" href="shop.php">
                            SHOP
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="shop.php">
                            NEW ARRIVALS
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="shop.php">
                            BEST SELLERS
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="shop.php">
                            OFFERS
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="about.php">
                            ABOUT US
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">
                            CONTACT US
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Page Content -->
    <?php echo $content ?? ''; ?>

    <!-- Footer -->
    <footer>
        <div class="container">

            <div class="cols">

                <div>
                    <div class="logo">
                        Madam<br>
                        <span>Glorious</span>
                    </div>

                    <p>
                        Stylish, comfortable and elegant ladies
                        footwear for every occasion.
                    </p>
                </div>

                <div>
                    <h3>Quick Links</h3>

                    <a href="index.php">Home</a>
                    <a href="shop.php">Shop</a>
                    <a href="about.php">About Us</a>
                    <a href="contact.php">Contact</a>
                </div>

                <div>
                    <h3>Customer</h3>

                    <a href="login.php">My Account</a>
                    <a href="cart.php">My Cart</a>
                    <a href="wishlist.php">Wishlist</a>
                    <a href="track-order.php">Track Order</a>
                </div>

                <div>
                    <h3>Contact</h3>

                    <a><i class="bi bi-telephone-fill me-2" aria-hidden="true"></i>+91 98765 43210</a>
                    <a><i class="bi bi-envelope-fill me-2" aria-hidden="true"></i>support@madamglorious.com</a>
                    <a><i class="bi bi-geo-alt-fill me-2" aria-hidden="true"></i>Rajkot, Gujarat, India</a>
                </div>

            </div>

            <div class="copyright">
                © 2026 Madam Glorious. Frontend demo project.
            </div>

        </div>
    </footer>

    <!-- Bootstrap JavaScript -->
    <script src="assets/bootstrap/bootstrap.bundle.min.js"></script>

    <!-- Custom JavaScript -->
    <script src="assets/js/app.js"></script>

    <!--Jquery CDN-->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- Validation js -->
    <script src="assets/js/validator.js"></script>

</body>

</html>