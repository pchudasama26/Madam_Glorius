<?php
$pageTitle = "My Orders | Madame Glorius";

$orders = [
    [
        "id" => "MG1025",
        "date" => "28 September 2026",
        "name" => "Classic Rose Heels",
        "image" => "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&w=700&q=80",
        "size" => 7,
        "quantity" => 1,
        "price" => 1499,
        "status" => "Delivered",
        "tracking" => true
    ],
    [
        "id" => "MG1024",
        "date" => "24 September 2026",
        "name" => "Pearl Strap Sandals",
        "image" => "https://images.unsplash.com/photo-1603487742131-4160ec999306?auto=format&fit=crop&w=700&q=80",
        "size" => 6,
        "quantity" => 1,
        "price" => 1199,
        "status" => "Shipped",
        "tracking" => true
    ],
    [
        "id" => "MG1023",
        "date" => "20 September 2026",
        "name" => "Everyday Comfort Flats",
        "image" => "https://images.unsplash.com/photo-1562273138-f46be4ebdf33?auto=format&fit=crop&w=700&q=80",
        "size" => 7,
        "quantity" => 1,
        "price" => 899,
        "status" => "Processing",
        "tracking" => true
    ],
    [
        "id" => "MG1022",
        "date" => "15 September 2026",
        "name" => "Urban White Sneakers",
        "image" => "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=700&q=80",
        "size" => 6,
        "quantity" => 1,
        "price" => 1799,
        "status" => "Delivered",
        "tracking" => true
    ],
    [
        "id" => "MG1021",
        "date" => "10 September 2026",
        "name" => "Golden Party Heels",
        "image" => "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=700&q=80",
        "size" => 7,
        "quantity" => 1,
        "price" => 1699,
        "status" => "Delivered",
        "tracking" => true
    ],
    [
        "id" => "MG1020",
        "date" => "05 September 2026",
        "name" => "Blush Block Heels",
        "image" => "https://images.unsplash.com/photo-1560343090-f0409e92791a?auto=format&fit=crop&w=700&q=80",
        "size" => 6,
        "quantity" => 1,
        "price" => 1399,
        "status" => "Delivered",
        "tracking" => false
    ]
];

ob_start();
?>

<!-- Page Heading -->


<section class="page-title order-page-title">
    <div class="container">
        <h1>My Orders</h1>
        <p>View and track your recent orders.</p>
        <div class="order-breadcrumb">
            <a href="index.php">Home</a>
            <span>/</span>
            <span>My Account</span>
            <span>/</span>
            <span>My Orders</span>
        </div>

    </div>
</section>


<!-- Orders -->
<section class="section orders-page">
    <div class="container">

        <div class="mg-order-list">

            <?php foreach ($orders as $order): ?>

                <article class="mg-order-card">

                    <!-- Product Image -->
                    <div class="mg-order-image">
                        <img src="<?= htmlspecialchars($order["image"]) ?>" alt="<?= htmlspecialchars($order["name"]) ?>"
                            loading="lazy">
                    </div>

                    <!-- Order Details -->
                    <div class="mg-order-info">

                        <div class="mg-order-top">
                            <p class="mg-order-number">
                                Order #<?= htmlspecialchars($order["id"]) ?>
                            </p>

                            <span class="mg-order-badge status-<?= strtolower($order["status"]) ?>">
                                <?= htmlspecialchars($order["status"]) ?>
                            </span>
                        </div>

                        <p class="mg-order-date">
                            Placed on <?= htmlspecialchars($order["date"]) ?>
                        </p>

                        <h3><?= htmlspecialchars($order["name"]) ?></h3>

                        <div class="mg-order-meta">
                            <span>Size: <?= (int) $order["size"] ?></span>
                            <span>Quantity: <?= (int) $order["quantity"] ?></span>
                        </div>

                        <p class="mg-order-price">
                            ₹<?= number_format($order["price"]) ?>
                        </p>

                        <div class="mg-order-actions">
                            <a href="order-details.php?id=<?= urlencode($order["id"]) ?>" class="btn outline">
                                VIEW ORDER
                            </a>

                            <?php if ($order["tracking"]): ?>
                                <a href="order-tracking.php?id=<?= urlencode($order["id"]) ?>" class="btn">
                                    TRACK ORDER
                                </a>
                            <?php endif; ?>
                        </div>

                    </div>
                </article>

            <?php endforeach; ?>

        </div>

        <!-- Continue Shopping -->
        <div class="mg-continue-shopping">
            <h3>Looking for something new?</h3>
            <p class="muted">Explore our latest footwear collection.</p>
            <a href="shop.php" class="btn">CONTINUE SHOPPING</a>
        </div>

    </div>
</section>

<?php
$content = ob_get_clean();
include 'layout.php';
?>