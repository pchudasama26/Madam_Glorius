<?php

$pageTitle = "Shop | Madam Glorious";

ob_start();

?>

<!-- Page Header -->
<div class="page-head">
    <div class="container">
        <h1>Shop Our Collection</h1>

        <div class="breadcrumb">
            Home / Shop
        </div>
    </div>
</div>


<!-- Shop Section -->
<section class="section">

    <div class="container products-layout">

        <!-- Sidebar -->
        <aside class="sidebar">

            <h3>FILTER PRODUCTS</h3>

            <hr>

            <b>Categories</b>

            <div class="filter">

                <label>
                    <input type="checkbox">
                    Heels
                </label>

                <label>
                    <input type="checkbox">
                    Flats
                </label>

                <label>
                    <input type="checkbox">
                    Sneakers
                </label>

                <label>
                    <input type="checkbox">
                    Sandals
                </label>

                <label>
                    <input type="checkbox">
                    Slippers
                </label>

            </div>

            <hr>

           <b>Price Range</b>

            <div class="price-range">

                <div class="price-values">
                <span>₹500</span>
                <strong id="priceValue">₹2,000</strong>
                </div>

                <input
                    type="range"
                    class="form-range"
                    id="priceRange"
                    min="500"
                    max="2000"
                    step="100"
                    value="2000"
                >

            </div>        

        </aside>


        <!-- Products -->
        <main>

            <!-- Product Heading -->
            <div
                style="
                    display: flex;
                    justify-content: space-between;
                    margin-bottom: 20px;
                "
            >

                <b>All Footwear</b>

                <span>8 Products</span>

            </div>


            <!-- Product Grid -->
            <div class="row g-4">


                <!-- Product 1 -->
                <div class="col-12 col-sm-6 col-md-4 col-lg-4">

                    <article class="card product-card">

                        <span class="badge">NEW</span>

                        <button
                            class="wishlist-btn"
                            type="button"
                            aria-label="Add to wishlist"
                            onclick="showToast('Wishlist feature added!')"
                        >
                            <i class="bi bi-heart" aria-hidden="true"></i>
                        </button>

                        <a
                            class="product-image-wrap"
                            href="product-details.php?id=1"
                        >

                            <img
                                src="assets/images/product-1.svg"
                                alt="Elegant Black Block Heels"
                                loading="lazy"
                            >

                            <span class="quick-view">
                                Quick View
                            </span>

                        </a>


                        <div class="card-body">

                            <small class="product-category">
                                Heels
                            </small>

                            <h3>
                                Elegant Black Block Heels
                            </h3>

                            <div class="rating-stars">
                                <i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i> <span>(12)</span>
                            </div>

                            <div class="price">
                                ₹1,499
                                <span class="old">
                                    ₹1,799
                                </span>
                            </div>


                            <div class="card-actions">

                                <a
                                    class="btn btn-outline"
                                    href="product-details.php?id=1"
                                >
                                    VIEW
                                </a>

                                <button
                                    class="btn"
                                    onclick="addCart(1)"
                                >
                                    ADD TO CART
                                </button>

                            </div>

                        </div>

                    </article>

                </div>


                <!-- Product 2 -->
                <div class="col-12 col-sm-6 col-md-4 col-lg-4">

                    <article class="card product-card">

                        <span class="badge">NEW</span>

                        <button
                            class="wishlist-btn"
                            type="button"
                            aria-label="Add to wishlist"
                            onclick="showToast('Wishlist feature added!')"
                        >
                            <i class="bi bi-heart" aria-hidden="true"></i>
                        </button>

                        <a
                            class="product-image-wrap"
                            href="product-details.php?id=2"
                        >

                            <img
                                src="assets/images/product-2.svg"
                                alt="White Casual Sneakers"
                                loading="lazy"
                            >

                            <span class="quick-view">
                                Quick View
                            </span>

                        </a>


                        <div class="card-body">

                            <small class="product-category">
                                Sneakers
                            </small>

                            <h3>
                                White Casual Sneakers
                            </h3>

                            <div class="rating-stars">
                                <i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i> <span>(12)</span>
                            </div>

                            <div class="price">
                                ₹1,299
                                <span class="old">
                                    ₹1,599
                                </span>
                            </div>


                            <div class="card-actions">

                                <a
                                    class="btn btn-outline"
                                    href="product-details.php?id=2"
                                >
                                    VIEW
                                </a>

                                <button
                                    class="btn"
                                    onclick="addCart(2)"
                                >
                                    ADD TO CART
                                </button>

                            </div>

                        </div>

                    </article>

                </div>


                <!-- Product 3 -->
                <div class="col-12 col-sm-6 col-md-4 col-lg-4">

                    <article class="card product-card">

                        <span class="badge">NEW</span>

                        <button
                            class="wishlist-btn"
                            type="button"
                            aria-label="Add to wishlist"
                            onclick="showToast('Wishlist feature added!')"
                        >
                            <i class="bi bi-heart" aria-hidden="true"></i>
                        </button>

                        <a
                            class="product-image-wrap"
                            href="product-details.php?id=3"
                        >

                            <img
                                src="assets/images/product-3.svg"
                                alt="Beige Party Wear Heels"
                                loading="lazy"
                            >

                            <span class="quick-view">
                                Quick View
                            </span>

                        </a>


                        <div class="card-body">

                            <small class="product-category">
                                Heels
                            </small>

                            <h3>
                                Beige Party Wear Heels
                            </h3>

                            <div class="rating-stars">
                                <i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i> <span>(12)</span>
                            </div>

                            <div class="price">
                                ₹1,699
                                <span class="old">
                                    ₹1,999
                                </span>
                            </div>


                            <div class="card-actions">

                                <a
                                    class="btn btn-outline"
                                    href="product-details.php?id=3"
                                >
                                    VIEW
                                </a>

                                <button
                                    class="btn"
                                    onclick="addCart(3)"
                                >
                                    ADD TO CART
                                </button>

                            </div>

                        </div>

                    </article>

                </div>


                <!-- Product 4 -->
                <div class="col-12 col-sm-6 col-md-4 col-lg-4">

                    <article class="card product-card">

                        <span class="badge">NEW</span>

                        <button
                            class="wishlist-btn"
                            type="button"
                            aria-label="Add to wishlist"
                            onclick="showToast('Wishlist feature added!')"
                        >
                            <i class="bi bi-heart" aria-hidden="true"></i>
                        </button>

                        <a
                            class="product-image-wrap"
                            href="product-details.php?id=4"
                        >

                            <img
                                src="assets/images/product-4.svg"
                                alt="Pink Comfort Flats"
                                loading="lazy"
                            >

                            <span class="quick-view">
                                Quick View
                            </span>

                        </a>


                        <div class="card-body">

                            <small class="product-category">
                                Flats
                            </small>

                            <h3>
                                Pink Comfort Flats
                            </h3>

                            <div class="rating-stars">
                                <i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i> <span>(12)</span>
                            </div>

                            <div class="price">
                                ₹899
                                <span class="old">
                                    ₹1,199
                                </span>
                            </div>


                            <div class="card-actions">

                                <a
                                    class="btn btn-outline"
                                    href="product-details.php?id=4"
                                >
                                    VIEW
                                </a>

                                <button
                                    class="btn"
                                    onclick="addCart(4)"
                                >
                                    ADD TO CART
                                </button>

                            </div>

                        </div>

                    </article>

                </div>


                <!-- Product 5 -->
                <div class="col-12 col-sm-6 col-md-4 col-lg-4">

                    <article class="card product-card">

                        <span class="badge">NEW</span>

                        <button
                            class="wishlist-btn"
                            type="button"
                            aria-label="Add to wishlist"
                            onclick="showToast('Wishlist feature added!')"
                        >
                            <i class="bi bi-heart" aria-hidden="true"></i>
                        </button>

                        <a
                            class="product-image-wrap"
                            href="product-details.php?id=5"
                        >

                            <img
                                src="assets/images/product-5.svg"
                                alt="Golden Traditional Sandals"
                                loading="lazy"
                            >

                            <span class="quick-view">
                                Quick View
                            </span>

                        </a>


                        <div class="card-body">

                            <small class="product-category">
                                Sandals
                            </small>

                            <h3>
                                Golden Traditional Sandals
                            </h3>

                            <div class="rating-stars">
                                <i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i> <span>(12)</span>
                            </div>

                            <div class="price">
                                ₹1,199
                                <span class="old">
                                    ₹1,499
                                </span>
                            </div>


                            <div class="card-actions">

                                <a
                                    class="btn btn-outline"
                                    href="product-details.php?id=5"
                                >
                                    VIEW
                                </a>

                                <button
                                    class="btn"
                                    onclick="addCart(5)"
                                >
                                    ADD TO CART
                                </button>

                            </div>

                        </div>

                    </article>

                </div>


                <!-- Product 6 -->
                <div class="col-12 col-sm-6 col-md-4 col-lg-4">

                    <article class="card product-card">

                        <span class="badge">NEW</span>

                        <button
                            class="wishlist-btn"
                            type="button"
                            aria-label="Add to wishlist"
                            onclick="showToast('Wishlist feature added!')"
                        >
                            <i class="bi bi-heart" aria-hidden="true"></i>
                        </button>

                        <a
                            class="product-image-wrap"
                            href="product-details.php?id=6"
                        >

                            <img
                                src="assets/images/product-6.svg"
                                alt="Rose Casual Slippers"
                                loading="lazy"
                            >

                            <span class="quick-view">
                                Quick View
                            </span>

                        </a>


                        <div class="card-body">

                            <small class="product-category">
                                Slippers
                            </small>

                            <h3>
                                Rose Casual Slippers
                            </h3>

                            <div class="rating-stars">
                                <i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i> <span>(12)</span>
                            </div>

                            <div class="price">
                                ₹699
                                <span class="old">
                                    ₹999
                                </span>
                            </div>


                            <div class="card-actions">

                                <a
                                    class="btn btn-outline"
                                    href="product-details.php?id=6"
                                >
                                    VIEW
                                </a>

                                <button
                                    class="btn"
                                    onclick="addCart(6)"
                                >
                                    ADD TO CART
                                </button>

                            </div>

                        </div>

                    </article>

                </div>


                <!-- Product 7 -->
                <div class="col-12 col-sm-6 col-md-4 col-lg-4">

                    <article class="card product-card">

                        <span class="badge">NEW</span>

                        <button
                            class="wishlist-btn"
                            type="button"
                            aria-label="Add to wishlist"
                            onclick="showToast('Wishlist feature added!')"
                        >
                            <i class="bi bi-heart" aria-hidden="true"></i>
                        </button>

                        <a
                            class="product-image-wrap"
                            href="product-details.php?id=7"
                        >

                            <img
                                src="assets/images/product-7.svg"
                                alt="Brown Wedge Heels"
                                loading="lazy"
                            >

                            <span class="quick-view">
                                Quick View
                            </span>

                        </a>


                        <div class="card-body">

                            <small class="product-category">
                                Wedges
                            </small>

                            <h3>
                                Brown Wedge Heels
                            </h3>

                            <div class="rating-stars">
                                <i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i> <span>(12)</span>
                            </div>

                            <div class="price">
                                ₹1,399
                                <span class="old">
                                    ₹1,699
                                </span>
                            </div>


                            <div class="card-actions">

                                <a
                                    class="btn btn-outline"
                                    href="product-details.php?id=7"
                                >
                                    VIEW
                                </a>

                                <button
                                    class="btn"
                                    onclick="addCart(7)"
                                >
                                    ADD TO CART
                                </button>

                            </div>

                        </div>

                    </article>

                </div>


                <!-- Product 8 -->
                <div class="col-12 col-sm-6 col-md-4 col-lg-4">

                    <article class="card product-card">

                        <span class="badge">NEW</span>

                        <button
                            class="wishlist-btn"
                            type="button"
                            aria-label="Add to wishlist"
                            onclick="showToast('Wishlist feature added!')"
                        >
                            <i class="bi bi-heart" aria-hidden="true"></i>
                        </button>

                        <a
                            class="product-image-wrap"
                            href="product-details.php?id=8"
                        >

                            <img
                                src="assets/images/product-8.svg"
                                alt="Red Party Heels"
                                loading="lazy"
                            >

                            <span class="quick-view">
                                Quick View
                            </span>

                        </a>


                        <div class="card-body">

                            <small class="product-category">
                                Heels
                            </small>

                            <h3>
                                Red Party Heels
                            </h3>

                            <div class="rating-stars">
                                <i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i><i class="bi bi-star-fill" aria-hidden="true"></i> <span>(12)</span>
                            </div>

                            <div class="price">
                                ₹1,799
                                <span class="old">
                                    ₹2,099
                                </span>
                            </div>


                            <div class="card-actions">

                                <a
                                    class="btn btn-outline"
                                    href="product-details.php?id=8"
                                >
                                    VIEW
                                </a>

                                <button
                                    class="btn"
                                    onclick="addCart(8)"
                                >
                                    ADD TO CART
                                </button>

                            </div>

                        </div>

                    </article>

                </div>

            </div>

        </main>

    </div>

</section>


<?php

$content = ob_get_clean();

include 'layout.php';

?>