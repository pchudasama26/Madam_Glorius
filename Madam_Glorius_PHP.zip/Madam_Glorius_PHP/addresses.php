<?php
session_start();

$pageTitle = "My Addresses | Madame Glorious";

// Sync profile data from session
$profile = $_SESSION['profile'] ?? [
    'first_name' => 'Madam',
    'last_name' => 'Glorious',
    'email' => 'customer@example.com',
];

/* Saved addresses in session */
if (!isset($_SESSION['addresses'])) {
    $_SESSION['addresses'] = [
        [
            'id' => 1,
            'type' => 'Home',
            'name' => trim(($profile['first_name'] ?? 'Madam') . ' ' . ($profile['last_name'] ?? 'Glorious')),
            'phone' => '9876543210',
            'line1' => '12, Rose Residency, Kalawad Road',
            'line2' => 'Near City Mall',
            'city' => 'Rajkot',
            'state' => 'Gujarat',
            'pincode' => '360005',
            'default' => true,
        ],
    ];
}

$message = "";

/* Delete address */
if (isset($_GET['delete'])) {
    $deleteId = (int) $_GET['delete'];
    $_SESSION['addresses'] = array_values(array_filter(
        $_SESSION['addresses'],
        fn($a) => $a['id'] !== $deleteId
    ));
    $message = "Address removed successfully.";
}

/* Make default address */
if (isset($_GET['default'])) {
    $defaultId = (int) $_GET['default'];
    foreach ($_SESSION['addresses'] as &$a) {
        $a['default'] = ($a['id'] === $defaultId);
    }
    unset($a);
    $message = "Default address updated.";
}

/* Add address */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $line1 = trim($_POST['line1'] ?? '');
    $line2 = trim($_POST['line2'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $state = trim($_POST['state'] ?? '');
    $pincode = trim($_POST['pincode'] ?? '');
    $type = trim($_POST['type'] ?? 'Home');

    $ids = array_column($_SESSION['addresses'], 'id');
    $newId = $ids ? max($ids) + 1 : 1;

    $_SESSION['addresses'][] = [
        'id' => $newId,
        'type' => $type,
        'name' => $name,
        'phone' => $phone,
        'line1' => $line1,
        'line2' => $line2,
        'city' => $city,
        'state' => $state,
        'pincode' => $pincode,
        'default' => empty($_SESSION['addresses']),
    ];
    $message = "New address saved successfully.";
    $_POST = [];
}

$addresses = $_SESSION['addresses'];

function e($v)
{
    return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
}

ob_start();
?>

<!-- PAGE TITLE -->
<section class="page-head">
    <div class="container">
        <h1>My Addresses</h1>
        <div class="breadcrumb justify-content-center">
            <a href="index.php">Home</a> &nbsp;/&nbsp; <a href="profile.php">My Account</a> &nbsp;/&nbsp;
            <span>Addresses</span>
        </div>
    </div>
</section>

<section class="section mg-dashboard">
    <div class="container">
        <div class="mg-dashboard-layout">

            <!-- SIDEBAR -->
            <aside class="mg-account-sidebar">
                <div class="mg-profile-summary">
                    <div class="mg-profile-icon">
                        <i class="bi bi-person"></i>
                    </div>
                    <h3><?= e(trim(($profile['first_name'] ?? 'Madam') . ' ' . ($profile['last_name'] ?? 'Glorious'))) ?>
                    </h3>
                    <p><?= e($profile['email'] ?? 'customer@example.com') ?></p>
                </div>

                <nav class="mg-account-menu">
                    <a href="dashboard.php" class="mg-menu-link">
                        <i class="bi bi-grid"></i> <span>Dashboard</span>
                    </a>
                    <a href="order.php" class="mg-menu-link">
                        <i class="bi bi-bag"></i> <span>My Orders</span>
                    </a>
                    <a href="profile.php" class="mg-menu-link">
                        <i class="bi bi-person"></i> <span>My Profile</span>
                    </a>
                    <a href="wishlist.php" class="mg-menu-link">
                        <i class="bi bi-heart"></i> <span>Wishlist</span>
                    </a>
                    <a href="addresses.php" class="mg-menu-link active">
                        <i class="bi bi-geo-alt"></i> <span>Addresses</span>
                    </a>
                    <a href="account_setitngs.php" class="mg-menu-link">
                        <i class="bi bi-gear"></i> <span>Account Settings</span>
                    </a>
                    <a href="logout.php" class="mg-menu-link mg-logout">
                        <i class="bi bi-box-arrow-right"></i> <span>Logout</span>
                    </a>
                </nav>
            </aside>

            <!-- MAIN CONTENT -->
            <div class="mg-dashboard-main">

                <?php if ($message !== ''): ?>
                    <div class="notice mb-4"><?= e($message) ?></div>
                <?php endif; ?>

                <!-- SAVED ADDRESSES -->
                <div class="form-wrap w-100 max-width-none mb-5">
                    <div class="border-bottom pb-2 mb-4">
                        <h3 class="fs-4 font-serif m-0">Saved Addresses</h3>
                        <small class="text-muted">Manage your delivery addresses for faster checkout.</small>
                    </div>

                    <div class="row g-4">
                        <?php if ($addresses): ?>
                            <?php foreach ($addresses as $a): ?>
                                <div class="col-md-6">
                                    <div class="card h-100 border p-3 position-relative shadow-sm">
                                        <div class="card-body p-2 d-flex flex-column justify-content-between">
                                            <div>
                                                <div class="d-flex justify-content-between align-items-center mb-2">
                                                    <span class="badge bg-secondary"><?= e($a['type']) ?></span>
                                                    <?php if ($a['default']): ?>
                                                        <span class="badge" style="background: var(--pink);">DEFAULT</span>
                                                    <?php endif; ?>
                                                </div>

                                                <h4 class="fs-5 font-serif mb-2"><?= e($a['name']) ?></h4>

                                                <p class="text-muted fs-6 mb-3">
                                                    <?= e($a['line1']) ?><br>
                                                    <?php if ($a['line2'] !== ''): ?>
                                                        <?= e($a['line2']) ?><br>
                                                    <?php endif; ?>
                                                    <?= e($a['city']) ?>, <?= e($a['state']) ?> - <?= e($a['pincode']) ?><br>
                                                    <strong>Phone:</strong> <?= e($a['phone']) ?>
                                                </p>
                                            </div>

                                            <div class="card-actions pt-2 border-top">
                                                <?php if (!$a['default']): ?>
                                                    <a class="btn btn-outline btn-sm me-2"
                                                        href="addresses.php?default=<?= (int) $a['id'] ?>">SET DEFAULT</a>
                                                <?php endif; ?>
                                                <a class="btn btn-sm" style="background:#b52d49; border-color:#b52d49;"
                                                    href="addresses.php?delete=<?= (int) $a['id'] ?>">REMOVE</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="col-12 text-center py-4">
                                <div class="fs-1 text-muted"><i class="bi bi-geo-alt"></i></div>
                                <h4 class="font-serif fs-5">No addresses saved</h4>
                                <p class="text-muted small">Add a delivery address using the form below.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- ADD NEW ADDRESS FORM -->
                <div class="form-wrap w-100 max-width-none">
                    <div class="border-bottom pb-2 mb-4">
                        <h3 class="fs-4 font-serif m-0">Add New Address</h3>
                    </div>

                    <form method="post" action="addresses.php">

                        <div class="two-col">
                            <div class="form-group">
                                <label for="name">Full Name</label>
                                <input type="text" id="name" name="name" class="form-control"
                                    placeholder="Enter full name" value="<?= e($_POST['name'] ?? '') ?>" required>
                                <span id="nameError" class="text-danger small"></span>
                            </div>
                            <div class="form-group">
                                <label for="phone">Mobile Number</label>
                                <input type="tel" id="phone" name="phone" class="form-control"
                                    placeholder="10-digit mobile number" maxlength="10"
                                    value="<?= e($_POST['phone'] ?? '') ?>" pattern="[0-9]{10}" required>
                                <span id="phoneError" class="text-danger small"></span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="line1">Address Line 1</label>
                            <input type="text" id="line1" name="line1" class="form-control"
                                placeholder="House no., building, street" value="<?= e($_POST['line1'] ?? '') ?>"
                                required>
                            <span id="line1Error" class="text-danger small"></span>
                        </div>

                        <div class="form-group">
                            <label for="line2">Address Line 2 (Optional)</label>
                            <input type="text" id="line2" name="line2" class="form-control" placeholder="Landmark, area"
                                value="<?= e($_POST['line2'] ?? '') ?>">
                            <span id="line2Error" class="text-danger small"></span>
                        </div>

                        <div class="two-col">
                            <div class="form-group">
                                <label for="city">City</label>
                                <input type="text" id="city" name="city" class="form-control" placeholder="City"
                                    value="<?= e($_POST['city'] ?? '') ?>" required>
                                <span id="cityError" class="text-danger small"></span>
                            </div>
                            <div class="form-group">
                                <label for="pincode">Pincode</label>
                                <input type="text" id="pincode" name="pincode" class="form-control"
                                    placeholder="6-digit pincode" maxlength="6"
                                    value="<?= e($_POST['pincode'] ?? '') ?>" pattern="[0-9]{6}" required>
                                <span id="pincodeError" class="text-danger small"></span>
                            </div>
                        </div>

                        <div class="two-col">
                            <div class="form-group">
                                <label for="state">State</label>
                                <select id="state" name="state" class="form-select" required>
                                    <option value="">Select state</option>
                                    <?php
                                    $states = ["Gujarat", "Maharashtra", "Rajasthan", "Madhya Pradesh", "Delhi", "Karnataka", "Tamil Nadu", "Uttar Pradesh", "West Bengal", "Punjab"];
                                    foreach ($states as $s):
                                        ?>
                                        <option value="<?= e($s) ?>" <?= (($_POST['state'] ?? '') === $s) ? 'selected' : '' ?>>
                                            <?= e($s) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <span id="stateError" class="text-danger small"></span>
                            </div>
                            <div class="form-group">
                                <label for="type">Address Type</label>
                                <select id="type" name="type" class="form-select" required>
                                    <option value="Home">Home</option>
                                    <option value="Office">Office</option>
                                    <option value="Other">Other</option>
                                </select>
                                <span id="typeError" class="text-danger small"></span>
                            </div>
                        </div>

                        <button type="submit" class="btn px-4 mt-2">SAVE ADDRESS</button>
                    </form>
                </div>

            </div>
        </div>
    </div>
</section>

<?php
$content = ob_get_clean();
include 'layout.php';
?>