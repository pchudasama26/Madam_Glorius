<?php

$pageTitle = "Register | Madam Glorious";

?>

<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?= htmlspecialchars($pageTitle) ?></title>

    <!-- Bootstrap CSS -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
        rel="stylesheet">

    <!-- Madam Glorious Styles -->
    <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>

    <div class="login-page register-page">

        <div class="login-card register-card">

            <!-- Brand -->
            <div class="login-brand">
                Madam <span>Glorious</span>
            </div>

            <p class="text-center text-muted mb-4">
                Create Your Account
            </p>

            <form id="registerForm" novalidate>

                <div class="two-col">

                    <!-- First Name -->
                    <div class="form-group">
                        <label for="fname">First Name</label>
                        <input
                            type="text"
                            class="form-control"
                            name="fname"
                            id="fname"
                            placeholder="Enter First Name"
                            data-validation="required alpha">
                        <span class="error text-danger" id="fnameError"></span>
                    </div>

                    <!-- Last Name -->
                    <div class="form-group">
                        <label for="lname">Last Name</label>
                        <input
                            type="text"
                            class="form-control"
                            name="lname"
                            id="lname"
                            placeholder="Enter Last Name"
                            data-validation="required alpha">
                        <span class="error text-danger" id="lnameError"></span>
                    </div>

                    <!-- Email -->
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input
                            type="text"
                            class="form-control"
                            name="email"
                            id="email"
                            placeholder="Enter Email"
                            data-validation="required email">
                        <span class="error text-danger" id="emailError"></span>
                    </div>

                    <!-- Mobile Number -->
                    <div class="form-group">
                        <label for="mobile">Mobile Number</label>
                        <input
                            type="text"
                            class="form-control"
                            name="mobile"
                            id="mobile"
                            placeholder="Enter Mobile Number"
                            data-validation="required numeric min max"
                            data-min="10"
                            data-max="10">
                        <span class="error text-danger" id="mobileError"></span>
                    </div>

                    <!-- Password -->
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input
                            type="password"
                            class="form-control"
                            name="password"
                            id="password"
                            placeholder="Enter Password"
                            data-validation="required strongPassword"
                            data-min="8"
                            data-max="25">
                        <span class="error text-danger" id="passwordError"></span>
                    </div>

                    <!-- Confirm Password -->
                    <div class="form-group">
                        <label for="confirmPassword">Confirm Password</label>
                        <input
                            type="password"
                            class="form-control"
                            name="confirmPassword"
                            id="confirmPassword"
                            placeholder="Confirm Password"
                            data-validation="required confirmPassword"
                            data-password-id="password">
                        <span class="error text-danger" id="confirmPasswordError"></span>
                    </div>

                </div>

                <!-- Create Account Button -->
                <button type="submit" class="btn btn-mg w-100 py-2 mt-2">
                    CREATE ACCOUNT
                </button>

            </form>

            <!-- Login Link -->
            <p class="text-center text-muted small mt-4 mb-0">
                Already have an account?
                <a href="login.php" class="register-login-link">Login</a>
            </p>

            <p class="text-center text-muted small mt-3 mb-0">
                Frontend demo — account creation is for demonstration only.
            </p>

        </div>

    </div>

    <!-- jQuery required by validator.js -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- Existing Form Validation -->
    <script src="assets/js/validator.js"></script>

    <script>
        $(document).ready(function () {
            $("#registerForm").on("submit", function (event) {
                // validator.js handles the validation first.
                if (event.isDefaultPrevented()) {
                    return;
                }

                event.preventDefault();
                alert("Account created (demo)!");
                window.location.href = "login.php";
            });
        });
    </script>

</body>

</html>
