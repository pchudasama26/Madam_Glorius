<?php
$pageTitle="Orders | Madam Glorious";
$activePage="orders";
ob_start();

?>

<div class="mb-4">
    <h2 class="page-title">
        Orders
    </h2>
    <div class="page-subtitle">
        View and manage customer orders.
    </div>
</div>
<div class="admin-card">
    <div class="card-header">
        <div class="row g-2">
            <div class="col-md-6">
                <input class="form-control" placeholder="Search order or customer">
            </div>
            <div class="col-md-3">
                <select class="form-select">
                    <option>
                        All Status
                    </option>
                    <option>
                        Pending
                    </option>
                    <option>
                        Shipped
                    </option>
                    <option>
                        Delivered
                    </option>
                </select>
            </div>
            <div class="col-md-3">
                <button class="btn btn-outline-mg w-100">
                    Filter
                </button>
            </div>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th>
                        Order ID
                    </th>
                    <th>
                        Customer
                    </th>
                    <th>
                        Date
                    </th>
                    <th>
                        Total
                    </th>
                    <th>
                        Status
                    </th>
                    <th>
                    </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        #MG1024
                    </td>
                    <td>
                        Priya Shah
                    </td>
                    <td>
                        06 Oct 2026
                    </td>
                    <td>
                        ₹2,798
                    </td>
                    <td>
                        <span class="status status-success">
                            Delivered
                        </span>
                    </td>
                    <td>
                        <a href="order-details.php" class="btn btn-sm btn-outline-mg">
                            View
                        </a>
                    </td>
                </tr>
                <tr>
                    <td>
                        #MG1023
                    </td>
                    <td>
                        Riya Patel
                    </td>
                    <td>
                        05 Oct 2026
                    </td>
                    <td>
                        ₹1,699
                    </td>
                    <td>
                        <span class="status status-warning">
                            Pending
                        </span>
                    </td>
                    <td>
                        <a href="order-details.php" class="btn btn-sm btn-outline-mg">
                            View
                        </a>
                    </td>
                </tr>
                <tr>
                    <td>
                        #MG1022
                    </td>
                    <td>
                        Neha Joshi
                    </td>
                    <td>
                        04 Oct 2026
                    </td>
                    <td>
                        ₹899
                    </td>
                    <td>
                        <span class="status status-info">
                            Shipped
                        </span>
                    </td>
                    <td>
                        <a href="order-details.php" class="btn btn-sm btn-outline-mg">
                            View
                        </a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<?php
$content=ob_get_clean();
include 'admin-layout.php';
?>
