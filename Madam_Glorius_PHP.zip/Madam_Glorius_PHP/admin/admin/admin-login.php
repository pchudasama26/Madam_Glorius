<?php

$pageTitle = 'Admin Login | Madam Glorious';

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($pageTitle) ?></title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="../assets/css/admin.css" rel="stylesheet">
</head>
<body>
    <div class="login-page">
        <div class="login-card">
            <div class="login-brand">Madam <span>Glorious</span></div>
            <p class="text-center text-muted mb-4">Admin Panel Login</p>

            <form action="dashboard.php" method="post" novalidate>
                <div class="mb-3">
                    <label for="adminEmail" class="form-label">Admin Email</label>
                    <input type="text" class="form-control" id="adminEmail" name="adminEmail" placeholder="admin@madamglorious.com" data-validation="required email" autocomplete="username">
                    <span class="error text-danger" id="adminEmailError"></span>
                </div>

                <div class="mb-3">
                    <label for="adminPassword" class="form-label">Password</label>
                    <input type="password" class="form-control" id="adminPassword" name="adminPassword" placeholder="Enter password" data-validation="required min max" data-min="8" data-max="25" autocomplete="current-password">
                    <span class="error text-danger" id="adminPasswordError"></span>
                </div>

                <div class="d-flex justify-content-between mb-4">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="remember">
                        <label class="form-check-label" for="remember">Remember me</label>
                    </div>
                    <a href="#" style="color:var(--mg-pink)">Forgot password?</a>
                </div>

                <button type="submit" class="btn btn-mg w-100 py-2">Login</button>
            </form>

            <p class="text-center text-muted small mt-4 mb-0">Frontend demo — authentication will be connected later.</p>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="../assets/js/validator.js"></script>
</body>
</html>
