<?php
$pageTitle = "Categories | Madam Glorious";
$activePage = "categories";
ob_start();

?>

<div class="d-flex justify-content-between align-items-end mb-4">
    <div>
        <h2 class="page-title">
            Categories
        </h2>
        <div class="page-subtitle">
            Manage footwear categories.
        </div>
    </div>
    <a href="add-category.php" class="btn btn-mg">
        + Add Category
    </a>
</div>
<div class="row g-3">
    <div class="col-12 col-sm-6 col-lg-4">
        <div class="stat-card">
            <div class="stat-icon mb-3">
                <i class="bi bi-tags">
                </i>
            </div>
            <h5>
                Heels
            </h5>
            <span class="text-muted small">
                3 products
            </span>
            <div class="mt-3">
                <a class="btn btn-sm btn-outline-mg" href="add-category.php">
                    Edit
                </a>
                <button class="btn btn-sm btn-outline-danger" data-confirm-delete>
                    Delete
                </button>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-lg-4">
        <div class="stat-card">
            <div class="stat-icon mb-3">
                <i class="bi bi-tags">
                </i>
            </div>
            <h5>
                Flats
            </h5>
            <span class="text-muted small">
                1 products
            </span>
            <div class="mt-3">
                <a href="add-category.php" class="btn btn-sm btn-outline-mg">
                    Edit
                </a>
                <button class="btn btn-sm btn-outline-danger" data-confirm-delete>
                    Delete
                </button>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-lg-4">
        <div class="stat-card">
            <div class="stat-icon mb-3">
                <i class="bi bi-tags">
                </i>
            </div>
            <h5>
                Sneakers
            </h5>
            <span class="text-muted small">
                1 products
            </span>
            <div class="mt-3">
                <a class="btn btn-sm btn-outline-mg" href="add-category.php">
                    Edit
                </a>
                <button class="btn btn-sm btn-outline-danger" data-confirm-delete>
                    Delete
                </button>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-lg-4">
        <div class="stat-card">
            <div class="stat-icon mb-3">
                <i class="bi bi-tags">
                </i>
            </div>
            <h5>
                Sandals
            </h5>
            <span class="text-muted small">
                1 products
            </span>
            <div class="mt-3">
                <a class="btn btn-sm btn-outline-mg" href="add-category.php">
                    Edit
                </a>
                <button class="btn btn-sm btn-outline-danger" data-confirm-delete>
                    Delete
                </button>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-lg-4">
        <div class="stat-card">
            <div class="stat-icon mb-3">
                <i class="bi bi-tags">
                </i>
            </div>
            <h5>
                Slippers
            </h5>
            <span class="text-muted small">
                1 products
            </span>
            <div class="mt-3">
                <a class="btn btn-sm btn-outline-mg" href="add-category.php">
                    Edit
                </a>
                <button class="btn btn-sm btn-outline-danger" data-confirm-delete>
                    Delete
                </button>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-lg-4">
        <div class="stat-card">
            <div class="stat-icon mb-3">
                <i class="bi bi-tags">
                </i>
            </div>
            <h5>
                Party Wear
            </h5>
            <span class="text-muted small">
                1 products
            </span>
            <div class="mt-3">
                <a class="btn btn-sm btn-outline-mg" href="add-category.php">
                    Edit
                </a>
                <button class="btn btn-sm btn-outline-danger" data-confirm-delete>
                    Delete
                </button>
            </div>
        </div>
    </div>
</div>
<?php
$content = ob_get_clean();
include 'admin-layout.php';
?>