<?php
$pageTitle="Order Details | Madam Glorious";
$activePage="orders";
ob_start();

?>

<div class="mb-4">
    <h2 class="page-title">
        Order #MG1024
    </h2>
    <div class="page-subtitle">
        Order details and customer information.
    </div>
</div>
<div class="row g-4">
    <div class="col-12 col-lg-8">
        <div class="admin-card">
            <div class="card-header">
                <strong>
                    Order Items
                </strong>
            </div>
            <div class="card-body">
                <img class="product-thumb me-2" src="../assets/images/product-1.svg">
                Elegant Black Block Heels &nbsp; × 1 &nbsp; ₹1,499
                <hr>
                <img class="product-thumb me-2" src="../assets/images/product-3.svg">
                Beige Party Wear Heels &nbsp; × 1 &nbsp; ₹1,299
            </div>
        </div>
    </div>
    <div class="col-12 col-lg-4">
        <div class="admin-card">
            <div class="card-header">
                <strong>
                    Customer
                </strong>
            </div>
            <div class="card-body">
                <h6>
                    Priya Shah
                </h6>
                <p class="text-muted">
                    priya@example.com
                    <br>
                    Rajkot, Gujarat
                </p>
                <hr>
                <strong>
                    Total: ₹2,798
                </strong>
            </div>
        </div>
    </div>
</div>

<?php
$content=ob_get_clean();
include 'admin-layout.php';
?>
