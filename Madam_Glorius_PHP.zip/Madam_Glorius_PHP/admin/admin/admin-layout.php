<?php

if (!isset($pageTitle)) {
    $pageTitle = 'Admin | Madam Glorious';
}

if (!isset($activePage)) {
    $activePage = 'dashboard';
}

?>

<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1">

    <title>
        <?= htmlspecialchars($pageTitle) ?>
    </title>

    <!-- Bootstrap CSS -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
        rel="stylesheet">

    <!-- Admin CSS -->
    <link
        href="../assets/css/admin.css"
        rel="stylesheet">

</head>

<body>

    <!-- Admin Sidebar -->
    <aside
        class="admin-sidebar"
        id="adminSidebar">

        <div class="admin-brand">
            Madam <span>Glorious</span>
        </div>

        <div class="admin-menu">

            <!-- Main -->
            <div class="menu-title">
                MAIN
            </div>

            <a
                class="nav-link <?= $activePage === 'dashboard' ? 'active' : '' ?>"
                href="dashboard.php">

                <i class="bi bi-grid-1x2-fill"></i>
                Dashboard

            </a>


            <a
                class="nav-link <?= $activePage === 'products' ? 'active' : '' ?>"
                href="products.php">

                <i class="bi bi-bag-fill"></i>
                Products

            </a>


            <a
                class="nav-link <?= $activePage === 'categories' ? 'active' : '' ?>"
                href="categories.php">

                <i class="bi bi-tags-fill"></i>
                Categories

            </a>


            <!-- Sales -->
            <div class="menu-title">
                SALES
            </div>

            <a
                class="nav-link <?= $activePage === 'orders' ? 'active' : '' ?>"
                href="orders.php">

                <i class="bi bi-box-seam-fill"></i>
                Orders

            </a>


            <a
                class="nav-link <?= $activePage === 'customers' ? 'active' : '' ?>"
                href="customers.php">

                <i class="bi bi-people-fill"></i>
                Customers

            </a>


            <a
                class="nav-link <?= $activePage === 'offers' ? 'active' : '' ?>"
                href="offers.php">

                <i class="bi bi-percent"></i>
                Offers

            </a>


            <!-- Analytics -->
            <div class="menu-title">
                ANALYTICS
            </div>

            <a
                class="nav-link <?= $activePage === 'reports' ? 'active' : '' ?>"
                href="reports.php">

                <i class="bi bi-bar-chart-fill"></i>
                Reports

            </a>


            <!-- Admin -->
            <div class="menu-title">
                ADMIN
            </div>

            <a
                class="nav-link <?= $activePage === 'profile' ? 'active' : '' ?>"
                href="profile.php">

                <i class="bi bi-person-circle"></i>
                Profile

            </a>


            <a
                class="nav-link <?= $activePage === 'settings' ? 'active' : '' ?>"
                href="settings.php">

                <i class="bi bi-gear-fill"></i>
                Settings

            </a>


            <a
                class="nav-link"
                href="../../login.php">

                <i class="bi bi-box-arrow-right"></i>
                Logout

            </a>

        </div>

    </aside>


    <!-- Main Area -->
    <div class="admin-main">

        <!-- Topbar -->
        <header class="admin-topbar">

            <button
                class="btn btn-light d-lg-none"
                id="sidebarToggle">

                <i class="bi bi-list fs-4"></i>

            </button>


            <strong class="d-none d-md-block">
                Madam Glorious Admin
            </strong>


            <!-- Admin Dropdown -->
            <div class="dropdown">

                <button
                    class="btn btn-light dropdown-toggle"
                    data-bs-toggle="dropdown">

                    <i class="bi bi-person-circle me-1"></i>
                    Admin

                </button>


                <ul class="dropdown-menu dropdown-menu-end">

                    <li>
                        <a
                            class="dropdown-item"
                            href="profile.php">
                            Profile
                        </a>
                    </li>

                    <li>
                        <a
                            class="dropdown-item"
                            href="settings.php">
                            Settings
                        </a>
                    </li>

                    <li>
                        <hr class="dropdown-divider">
                    </li>

                    <li>
                        <a
                            class="dropdown-item"
                            href="../../login.php">
                            Logout
                        </a>
                    </li>

                </ul>

            </div>

        </header>


        <!-- Page Content -->
        <main class="admin-page">

            <?= $content ?>

        </main>


        <!-- Footer -->
        <div class="admin-footer">
            © 2026 Madam Glorious Admin Panel
        </div>

    </div>


    <!-- jQuery (required by validator.js) -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- Instructor-provided form validation -->
    <script src="../assets/js/validator.js"></script>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Admin JS -->
    <script src="../assets/js/admin.js"></script>

</body>

</html>
