<?php
$pageTitle="Products | Madam Glorious";
$activePage="products";
ob_start();

?>

<div class="d-flex flex-wrap justify-content-between align-items-end mb-4">
    <div>
        <h2 class="page-title">
            Products
        </h2>
        <div class="page-subtitle">
            Manage Madam Glorious footwear catalogue.
        </div>
    </div>
    <a href="add-product.php" class="btn btn-mg">
        + Add Product
    </a>
</div>
<div class="admin-card">
    <div class="card-header">
        <div class="row g-2">
            <div class="col-md-6">
                <input class="form-control" placeholder="Search products...">
            </div>
            <div class="col-md-3">
                <select class="form-select">
                    <option>
                        All Categories
                    </option>
                    <option>
                        Heels
                    </option>
                    <option>
                        Flats
                    </option>
                    <option>
                        Sneakers
                    </option>
                    <option>
                        Sandals
                    </option>
                    <option>
                        Slippers
                    </option>
                </select>
            </div>
            <div class="col-md-3">
                <button class="btn btn-outline-mg w-100">
                    Search
                </button>
            </div>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th>
                        Product
                    </th>
                    <th>
                        Category
                    </th>
                    <th>
                        Price
                    </th>
                    <th>
                        Stock
                    </th>
                    <th>
                        Status
                    </th>
                    <th>
                        Action
                    </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        <img class="product-thumb me-2" src="../assets/images/product-1.svg">
                        Elegant Black Block Heels
                    </td>
                    <td>
                        Heels
                    </td>
                    <td>
                        ₹1,499
                    </td>
                    <td>
                        11
                    </td>
                    <td>
                        <span class="status status-success">
                            Active
                        </span>
                    </td>
                    <td>
                        <a href="edit-product.php?id=1" class="btn btn-sm btn-outline-mg">
                            Edit
                        </a>
                        <button class="btn btn-sm btn-outline-danger" data-confirm-delete>
                            Delete
                        </button>
                    </td>
                </tr>
                <tr>
                    <td>
                        <img class="product-thumb me-2" src="../assets/images/product-2.svg">
                        White Casual Sneakers
                    </td>
                    <td>
                        Sneakers
                    </td>
                    <td>
                        ₹1,299
                    </td>
                    <td>
                        12
                    </td>
                    <td>
                        <span class="status status-success">
                            Active
                        </span>
                    </td>
                    <td>
                        <a href="edit-product.php?id=2" class="btn btn-sm btn-outline-mg">
                            Edit
                        </a>
                        <button class="btn btn-sm btn-outline-danger" data-confirm-delete>
                            Delete
                        </button>
                    </td>
                </tr>
                <tr>
                    <td>
                        <img class="product-thumb me-2" src="../assets/images/product-3.svg">
                        Beige Party Wear Heels
                    </td>
                    <td>
                        Heels
                    </td>
                    <td>
                        ₹1,699
                    </td>
                    <td>
                        13
                    </td>
                    <td>
                        <span class="status status-success">
                            Active
                        </span>
                    </td>
                    <td>
                        <a href="edit-product.php?id=3" class="btn btn-sm btn-outline-mg">
                            Edit
                        </a>
                        <button class="btn btn-sm btn-outline-danger" data-confirm-delete>
                            Delete
                        </button>
                    </td>
                </tr>
                <tr>
                    <td>
                        <img class="product-thumb me-2" src="../assets/images/product-4.svg">
                        Pink Comfort Flats
                    </td>
                    <td>
                        Flats
                    </td>
                    <td>
                        ₹899
                    </td>
                    <td>
                        14
                    </td>
                    <td>
                        <span class="status status-success">
                            Active
                        </span>
                    </td>
                    <td>
                        <a href="edit-product.php?id=4" class="btn btn-sm btn-outline-mg">
                            Edit
                        </a>
                        <button class="btn btn-sm btn-outline-danger" data-confirm-delete>
                            Delete
                        </button>
                    </td>
                </tr>
                <tr>
                    <td>
                        <img class="product-thumb me-2" src="../assets/images/product-5.svg">
                        Golden Traditional Sandals
                    </td>
                    <td>
                        Sandals
                    </td>
                    <td>
                        ₹1,199
                    </td>
                    <td>
                        15
                    </td>
                    <td>
                        <span class="status status-success">
                            Active
                        </span>
                    </td>
                    <td>
                        <a href="edit-product.php?id=5" class="btn btn-sm btn-outline-mg">
                            Edit
                        </a>
                        <button class="btn btn-sm btn-outline-danger" data-confirm-delete>
                            Delete
                        </button>
                    </td>
                </tr>
                <tr>
                    <td>
                        <img class="product-thumb me-2" src="../assets/images/product-6.svg">
                        Rose Casual Slippers
                    </td>
                    <td>
                        Slippers
                    </td>
                    <td>
                        ₹699
                    </td>
                    <td>
                        16
                    </td>
                    <td>
                        <span class="status status-success">
                            Active
                        </span>
                    </td>
                    <td>
                        <a href="edit-product.php?id=6" class="btn btn-sm btn-outline-mg">
                            Edit
                        </a>
                        <button class="btn btn-sm btn-outline-danger" data-confirm-delete>
                            Delete
                        </button>
                    </td>
                </tr>
                <tr>
                    <td>
                        <img class="product-thumb me-2" src="../assets/images/product-7.svg">
                        Brown Wedge Heels
                    </td>
                    <td>
                        Wedges
                    </td>
                    <td>
                        ₹1,399
                    </td>
                    <td>
                        17
                    </td>
                    <td>
                        <span class="status status-success">
                            Active
                        </span>
                    </td>
                    <td>
                        <a href="edit-product.php?id=7" class="btn btn-sm btn-outline-mg">
                            Edit
                        </a>
                        <button class="btn btn-sm btn-outline-danger" data-confirm-delete>
                            Delete
                        </button>
                    </td>
                </tr>
                <tr>
                    <td>
                        <img class="product-thumb me-2" src="../assets/images/product-8.svg">
                        Red Party Heels
                    </td>
                    <td>
                        Heels
                    </td>
                    <td>
                        ₹1,799
                    </td>
                    <td>
                        18
                    </td>
                    <td>
                        <span class="status status-success">
                            Active
                        </span>
                    </td>
                    <td>
                        <a href="edit-product.php?id=8" class="btn btn-sm btn-outline-mg">
                            Edit
                        </a>
                        <button class="btn btn-sm btn-outline-danger" data-confirm-delete>
                            Delete
                        </button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<?php
$content=ob_get_clean();
include 'admin-layout.php';
?>
