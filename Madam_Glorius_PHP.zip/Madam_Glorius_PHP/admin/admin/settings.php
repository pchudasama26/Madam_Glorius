<?php

$pageTitle = "Settings | Madam Glorious";
$activePage = "settings";

ob_start();

?>

<div class="mb-4">
    <h2 class="page-title">Settings</h2>
    <div class="page-subtitle">Basic administration settings for Madam Glorious.</div>
</div>

<div class="row g-4">
    <div class="col-12 col-lg-6">
        <div class="admin-card">
            <div class="card-header"><strong>Store Settings</strong></div>
            <div class="card-body">
                <form method="post" novalidate data-demo-success="Store settings passed validation (demo). Saving settings will be connected later.">
                    <div class="mb-3">
                        <label for="storeName" class="form-label">Store Name</label>
                        <input type="text" class="form-control" id="storeName" name="storeName" value="Madam Glorious" data-validation="required alpha">
                        <span class="error text-danger" id="storeNameError"></span>
                    </div>

                    <div class="mb-3">
                        <label for="storeEmail" class="form-label">Store Email</label>
                        <input type="text" class="form-control" id="storeEmail" name="storeEmail" value="support@madamglorious.com" data-validation="required email">
                        <span class="error text-danger" id="storeEmailError"></span>
                    </div>

                    <div class="mb-3">
                        <label for="currency" class="form-label">Currency</label>
                        <select class="form-select" id="currency" name="currency" data-validation="required">
                            <option value="">Select currency</option>
                            <option value="INR">Indian Rupee (₹)</option>
                        </select>
                        <span class="error text-danger" id="currencyError"></span>
                    </div>

                    <button type="submit" class="btn btn-mg mt-3">Save Settings</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-12 col-lg-6">
        <div class="admin-card">
            <div class="card-header"><strong>Notifications</strong></div>
            <div class="card-body">
                <div class="form-check form-switch mb-3">
                    <input class="form-check-input" type="checkbox" id="newOrderNotifications" checked>
                    <label class="form-check-label" for="newOrderNotifications">New order notifications</label>
                </div>
                <div class="form-check form-switch mb-3">
                    <input class="form-check-input" type="checkbox" id="lowStockAlerts" checked>
                    <label class="form-check-label" for="lowStockAlerts">Low stock alerts</label>
                </div>
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" id="promotionalNotifications">
                    <label class="form-check-label" for="promotionalNotifications">Promotional notifications</label>
                </div>
            </div>
        </div>
    </div>
</div>

<?php

$content = ob_get_clean();

include 'admin-layout.php';

?>
