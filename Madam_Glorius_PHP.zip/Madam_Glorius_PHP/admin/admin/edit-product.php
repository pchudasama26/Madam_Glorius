<?php

$pageTitle = "Edit Product | Madam Glorious";
$activePage = "products";

ob_start();

?>

<div class="mb-4">
    <h2 class="page-title">Edit Product</h2>
    <div class="page-subtitle">Update product information.</div>
</div>

<form method="post" novalidate data-demo-success="Product details passed validation (demo). Saving changes will be connected later.">
    <div class="row g-4">
        <div class="col-12 col-xl-8">
            <div class="admin-card">
                <div class="card-header"><strong>Product Information</strong></div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="productName" class="form-label">Product Name</label>
                        <input type="text" class="form-control" id="productName" name="productName" placeholder="Enter product name" data-validation="required min max" data-min="3" data-max="80">
                        <span class="error text-danger" id="productNameError"></span>
                    </div>

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="productCategory" class="form-label">Category</label>
                            <select class="form-select" id="productCategory" name="productCategory" data-validation="required">
                                <option value="">Select category</option>
                                <option value="Heels">Heels</option>
                                <option value="Flats">Flats</option>
                                <option value="Sneakers">Sneakers</option>
                                <option value="Sandals">Sandals</option>
                                <option value="Slippers">Slippers</option>
                                <option value="Wedges">Wedges</option>
                            </select>
                            <span class="error text-danger" id="productCategoryError"></span>
                        </div>

                        <div class="col-md-3">
                            <label for="price" class="form-label">Price</label>
                            <input type="number" min="1" step="1" class="form-control" id="price" name="price" placeholder="1499" data-validation="required numeric">
                            <span class="error text-danger" id="priceError"></span>
                        </div>

                        <div class="col-md-3">
                            <label for="oldPrice" class="form-label">Old Price</label>
                            <input type="number" min="1" step="1" class="form-control" id="oldPrice" name="oldPrice" placeholder="1799" data-validation="required numeric">
                            <span class="error text-danger" id="oldPriceError"></span>
                        </div>
                    </div>

                    <div class="row g-3 mt-1">
                        <div class="col-md-6">
                            <label for="stock" class="form-label">Stock Quantity</label>
                            <input type="number" min="0" step="1" class="form-control" id="stock" name="stock" placeholder="20" data-validation="required numeric">
                            <span class="error text-danger" id="stockError"></span>
                        </div>

                        <div class="col-md-6">
                            <label for="productStatus" class="form-label">Status</label>
                            <select class="form-select" id="productStatus" name="productStatus" data-validation="required">
                                <option value="">Select status</option>
                                <option value="Active">Active</option>
                                <option value="Draft">Draft</option>
                                <option value="Out of Stock">Out of Stock</option>
                            </select>
                            <span class="error text-danger" id="productStatusError"></span>
                        </div>
                    </div>

                    <div class="mt-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="5" placeholder="Write product description..." data-validation="required min max" data-min="10" data-max="500"></textarea>
                        <span class="error text-danger" id="descriptionError"></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-xl-4">
            <div class="admin-card">
                <div class="card-header"><strong>Product Image</strong></div>
                <div class="card-body">
                    <label for="productImage" class="form-label">Replace Image (optional)</label>
                    <input type="file" class="form-control" id="productImage" name="productImage" accept=".jpg,.jpeg,.png">
                    <small class="text-muted">Leave this blank to keep the current image.</small>
                </div>
            </div>

            <div class="d-flex gap-2 mt-3">
                <a href="products.php" class="btn btn-light flex-fill">Cancel</a>
                <button type="submit" class="btn btn-mg flex-fill">Save Product</button>
            </div>
        </div>
    </div>
</form>

<?php

$content = ob_get_clean();

include 'admin-layout.php';

?>
