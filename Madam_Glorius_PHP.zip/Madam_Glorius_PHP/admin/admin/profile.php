<?php

$pageTitle = "Profile | Madam Glorious";
$activePage = "profile";

ob_start();

?>

<div class="mb-4">
    <h2 class="page-title">Admin Profile</h2>
    <div class="page-subtitle">Manage administrator profile information.</div>
</div>

<div class="admin-card">
    <div class="card-body">
        <form method="post" novalidate data-demo-success="Profile form passed validation (demo). Profile saving will be connected later.">
            <div class="row g-3">
                <div class="col-md-6">
                    <label for="adminName" class="form-label">Name</label>
                    <input type="text" class="form-control" id="adminName" name="adminName" value="Madam Glorious Admin" data-validation="required alpha">
                    <span class="error text-danger" id="adminNameError"></span>
                </div>

                <div class="col-md-6">
                    <label for="adminEmail" class="form-label">Email</label>
                    <input type="text" class="form-control" id="adminEmail" name="adminEmail" value="admin@madamglorious.com" data-validation="required email">
                    <span class="error text-danger" id="adminEmailError"></span>
                </div>

                <div class="col-md-6">
                    <label for="adminPhone" class="form-label">Phone</label>
                    <input type="text" class="form-control" id="adminPhone" name="adminPhone" value="+91 98765 43210" data-validation="required">
                    <span class="error text-danger" id="adminPhoneError"></span>
                </div>

                <div class="col-md-6">
                    <label for="adminRole" class="form-label">Role</label>
                    <input type="text" class="form-control" id="adminRole" name="adminRole" value="Administrator" disabled>
                </div>
            </div>

            <button type="submit" class="btn btn-mg mt-4">Save Changes</button>
        </form>
    </div>
</div>

<?php

$content = ob_get_clean();

include 'admin-layout.php';

?>
