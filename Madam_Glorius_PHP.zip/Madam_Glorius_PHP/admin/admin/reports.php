<?php
$pageTitle="Reports | Madam Glorious";
$activePage="reports";
ob_start();

?>

<div class="mb-4">
    <h2 class="page-title">
        Reports
    </h2>
    <div class="page-subtitle">
        Store performance overview using demo data.
    </div>
</div>
<div class="row g-3 mb-4">
    <div class="col-12 col-md-4">
        <div class="stat-card">
            <div class="stat-label">
                Total Sales
            </div>
            <div class="stat-number">
                ₹48,650
            </div>
        </div>
    </div>
    <div class="col-12 col-md-4">
        <div class="stat-card">
            <div class="stat-label">
                Orders
            </div>
            <div class="stat-number">
                24
            </div>
        </div>
    </div>
    <div class="col-12 col-md-4">
        <div class="stat-card">
            <div class="stat-label">
                Average Order
            </div>
            <div class="stat-number">
                ₹2,027
            </div>
        </div>
    </div>
</div>
<div class="admin-card">
    <div class="card-header">
        <strong>
            Monthly Sales
        </strong>
    </div>
    <div class="chart-placeholder">
        <div class="chart-bar" style="height:35%">
        </div>
        <div class="chart-bar" style="height:48%">
        </div>
        <div class="chart-bar" style="height:42%">
        </div>
        <div class="chart-bar" style="height:62%">
        </div>
        <div class="chart-bar" style="height:55%">
        </div>
        <div class="chart-bar" style="height:78%">
        </div>
        <div class="chart-bar" style="height:68%">
        </div>
        <div class="chart-bar" style="height:92%">
        </div>
    </div>
</div>

<?php
$content=ob_get_clean();
include 'admin-layout.php';
?>
