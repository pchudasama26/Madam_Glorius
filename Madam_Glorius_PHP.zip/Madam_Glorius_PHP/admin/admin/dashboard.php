<?php
$pageTitle="Dashboard | Madam Glorious";
$activePage="dashboard";
ob_start();

?>

<div class="d-flex flex-wrap justify-content-between align-items-end mb-4">
    <div>
        <h2 class="page-title">
            Dashboard
        </h2>
        <div class="page-subtitle">
            Overview of your women's footwear store.
        </div>
    </div>
    <a href="add-product.php" class="btn btn-mg mt-3 mt-md-0">
        <i class="bi bi-plus-lg">
        </i>
        Add Product
    </a>
</div>
<div class="row g-3 mb-4">
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="stat-card">
            <div class="d-flex justify-content-between">
                <div>
                    <div class="stat-label">
                        Total Products
                    </div>
                    <div class="stat-number">
                        8
                    </div>
                </div>
                <div class="stat-icon">
                    <i class="bi bi-bag">
                    </i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="stat-card">
            <div class="d-flex justify-content-between">
                <div>
                    <div class="stat-label">
                        Orders
                    </div>
                    <div class="stat-number">
                        24
                    </div>
                </div>
                <div class="stat-icon">
                    <i class="bi bi-box-seam">
                    </i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="stat-card">
            <div class="d-flex justify-content-between">
                <div>
                    <div class="stat-label">
                        Customers
                    </div>
                    <div class="stat-number">
                        156
                    </div>
                </div>
                <div class="stat-icon">
                    <i class="bi bi-people">
                    </i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="stat-card">
            <div class="d-flex justify-content-between">
                <div>
                    <div class="stat-label">
                        Revenue
                    </div>
                    <div class="stat-number">
                        ₹48,650
                    </div>
                </div>
                <div class="stat-icon">
                    <i class="bi bi-currency-rupee">
                    </i>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="admin-card">
    <div class="card-header">
        <strong>
            Recent Orders
        </strong>
    </div>
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th>
                        Order
                    </th>
                    <th>
                        Customer
                    </th>
                    <th>
                        Amount
                    </th>
                    <th>
                        Status
                    </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        #MG1024
                    </td>
                    <td>
                        Priya Shah
                    </td>
                    <td>
                        ₹2,798
                    </td>
                    <td>
                        <span class="status status-success">
                            Delivered
                        </span>
                    </td>
                </tr>
                <tr>
                    <td>
                        #MG1023
                    </td>
                    <td>
                        Riya Patel
                    </td>
                    <td>
                        ₹1,699
                    </td>
                    <td>
                        <span class="status status-warning">
                            Pending
                        </span>
                    </td>
                </tr>
                <tr>
                    <td>
                        #MG1022
                    </td>
                    <td>
                        Neha Joshi
                    </td>
                    <td>
                        ₹899
                    </td>
                    <td>
                        <span class="status status-info">
                            Shipped
                        </span>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<?php
$content=ob_get_clean();
include 'admin-layout.php';
?>
