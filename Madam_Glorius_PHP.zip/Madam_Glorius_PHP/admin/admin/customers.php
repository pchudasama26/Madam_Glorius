<?php

$pageTitle = "Customers | Madam Glorious";
$activePage = "customers";

ob_start();

?>

<div class="mb-4">
    <h2 class="page-title">Customers</h2>
    <div class="page-subtitle">Manage registered Madam Glorious customers.</div>
</div>

<div class="admin-card">
    <div class="card-header">
        <input class="form-control" placeholder="Search customer by name or email" aria-label="Search customer by name or email">
    </div>

    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th>Customer</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Orders</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <tr data-user-id="priya@example.com" data-default-status="active">
                    <td>Priya Shah</td>
                    <td>priya@example.com</td>
                    <td>98765 43210</td>
                    <td>4</td>
                    <td><span class="status status-success" data-user-status>Active</span></td>
                    <td>
                        <button type="button" class="btn btn-sm btn-outline-danger" data-user-toggle>Disable</button>
                    </td>
                </tr>
                <tr data-user-id="riya@example.com" data-default-status="active">
                    <td>Riya Patel</td>
                    <td>riya@example.com</td>
                    <td>riya@example.com</td>
                    <td>2</td>
                    <td><span class="status status-success" data-user-status>Active</span></td>
                    <td>
                        <button type="button" class="btn btn-sm btn-outline-danger" data-user-toggle>Disable</button>
                    </td>
                </tr>
                <tr data-user-id="neha@example.com" data-default-status="inactive">
                    <td>Neha Joshi</td>
                    <td>neha@example.com</td>
                    <td>99887 66554</td>
                    <td>1</td>
                    <td><span class="status status-warning" data-user-status>Inactive</span></td>
                    <td>
                        <button type="button" class="btn btn-sm btn-outline-success" data-user-toggle>Enable</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<?php

$content = ob_get_clean();

include 'admin-layout.php';

?>
