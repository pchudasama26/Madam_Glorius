<?php

$pageTitle = "Add Category | Madam Glorious";
$activePage = "categories";

ob_start();

?>

<div class="mb-4">
    <h2 class="page-title">Add Category</h2>
    <div class="page-subtitle">Create a new category for the footwear catalogue.</div>
</div>

<form method="post" novalidate data-demo-success="Category name passed validation (demo). Saving categories will be connected later.">
    <div class="admin-card">
        <div class="card-header">
            <strong>Category Information</strong>
        </div>

        <div class="card-body">
            <div class="mb-3">
                <label for="categoryName" class="form-label">Category Name</label>
                <input type="text" class="form-control" id="categoryName" name="categoryName" placeholder="Enter category name" data-validation="required alpha" autocomplete="off">
                <span class="error text-danger" id="categoryNameError"></span>
                <small class="text-muted">Use letters and spaces only, for example: Party Wear.</small>
            </div>
        </div>
    </div>

    <div class="d-flex flex-wrap gap-2 mt-3">
        <a href="categories.php" class="btn btn-light">Cancel</a>
        <button type="submit" class="btn btn-mg">Save Category</button>
    </div>
</form>

<?php

$content = ob_get_clean();

include 'admin-layout.php';

?>
