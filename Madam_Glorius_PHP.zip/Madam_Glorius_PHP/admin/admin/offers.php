<?php
$pageTitle="Offers | Madam Glorious";
$activePage="offers";
ob_start();

?>

<div class="mb-4">
    <h2 class="page-title">
        Offers & Discounts
    </h2>
    <div class="page-subtitle">
        Manage promotional offers for footwear products.
    </div>
</div>
<div class="row g-3">
    <div class="col-12 col-md-6 col-xl-4">
        <div class="stat-card">
            <span class="status status-success">
                ACTIVE
            </span>
            <h4 class="mt-3">
                WELCOME10
            </h4>
            <p class="text-muted">
                10% off on first order
            </p>
            <hr>
            <strong>
                Valid until 31 Dec 2026
            </strong>
        </div>
    </div>
    <div class="col-12 col-md-6 col-xl-4">
        <div class="stat-card">
            <span class="status status-success">
                ACTIVE
            </span>
            <h4 class="mt-3">
                FESTIVE20
            </h4>
            <p class="text-muted">
                20% off selected party wear
            </p>
            <hr>
            <strong>
                Valid until 30 Nov 2026
            </strong>
        </div>
    </div>
    <div class="col-12 col-md-6 col-xl-4">
        <div class="stat-card">
            <span class="status status-danger">
                EXPIRED
            </span>
            <h4 class="mt-3">
                SUMMER15
            </h4>
            <p class="text-muted">
                15% summer collection discount
            </p>
            <hr>
            <strong>
                Expired 31 Aug 2026
            </strong>
        </div>
    </div>
</div>

<?php
$content=ob_get_clean();
include 'admin-layout.php';
?>
