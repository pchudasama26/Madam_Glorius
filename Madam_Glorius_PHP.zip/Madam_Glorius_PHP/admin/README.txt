MADAM GLORIOUS ADMIN SIDE
Frontend-only Bootstrap admin panel for the women's footwear ecommerce project.

Structure:
- admin/admin/ contains the admin pages and shared admin-layout.php.
- admin/assets/css/admin.css contains the admin theme styles.
- admin/assets/js/admin.js contains the mobile sidebar, delete confirmation, demo customer status toggle, and demo-form messages.
- admin/assets/js/validator.js contains the validation rules supplied by the project owner/instructor.

Pages include admin-login, dashboard, products, add-product, edit-product, categories, add-category, orders, order-details, customers, offers, reports, profile and settings.

Validation:
- jQuery is loaded before validator.js from admin-layout.php and admin-login.php.
- Forms use data-validation attributes and matching error spans to show Bootstrap valid/invalid styles.
- Add Category is available from Categories > Add Category.

Demo limitations:
- Enable/Disable status is saved in this browser using localStorage only. It does not actually block a customer from logging in.
- Forms show demo validation-success messages; records are not saved because this package does not include a backend or database.
- Real user blocking, authentication, create/edit/delete actions, orders and reporting require server-side PHP/database integration.

Theme colors follow Madam Glorious: #6B3F4A, #2B2527, #F7F1EA, #F1E6DC.
