document.addEventListener('DOMContentLoaded', function () {
    const sidebar = document.getElementById('adminSidebar');
    const sidebarToggle = document.getElementById('sidebarToggle');

    if (sidebarToggle && sidebar) {
        sidebarToggle.addEventListener('click', function () {
            sidebar.classList.toggle('show');
        });
    }

    document.querySelectorAll('[data-confirm-delete]').forEach(function (button) {
        button.addEventListener('click', function (event) {
            if (!confirm('Are you sure you want to delete this item?')) {
                event.preventDefault();
            }
        });
    });

    function applyUserStatus(row, status) {
        const statusBadge = row.querySelector('[data-user-status]');
        const toggleButton = row.querySelector('[data-user-toggle]');

        if (!statusBadge || !toggleButton) {
            return;
        }

        row.dataset.currentStatus = status;
        statusBadge.textContent = status === 'active' ? 'Active' : 'Inactive';
        statusBadge.classList.remove('status-success', 'status-warning', 'status-danger');
        statusBadge.classList.add(status === 'active' ? 'status-success' : 'status-warning');

        toggleButton.textContent = status === 'active' ? 'Disable' : 'Enable';
        toggleButton.classList.remove('btn-outline-danger', 'btn-outline-success');
        toggleButton.classList.add(status === 'active' ? 'btn-outline-danger' : 'btn-outline-success');
        toggleButton.setAttribute('aria-pressed', status === 'inactive' ? 'true' : 'false');
    }

    document.querySelectorAll('[data-user-toggle]').forEach(function (button) {
        const row = button.closest('tr');

        if (!row || !row.dataset.userId) {
            return;
        }

        const storageKey = 'mg_admin_user_status_' + row.dataset.userId;
        const savedStatus = localStorage.getItem(storageKey);
        applyUserStatus(row, savedStatus || row.dataset.defaultStatus || 'active');

        button.addEventListener('click', function () {
            const currentStatus = row.dataset.currentStatus || 'active';
            const nextStatus = currentStatus === 'active' ? 'inactive' : 'active';

            applyUserStatus(row, nextStatus);
            localStorage.setItem(storageKey, nextStatus);
        });
    });

    // These forms are frontend demos: show success only after validator.js accepts every field.
    document.querySelectorAll('form[data-demo-success]').forEach(function (form) {
        form.addEventListener('submit', function (event) {
            if (event.defaultPrevented) {
                return;
            }

            event.preventDefault();
            window.alert(form.getAttribute('data-demo-success'));
        });
    });
});
