<?php
session_start();

$pageTitle = "Account Settings | Madame Glorious";

// Profile session check or default sync
$profile = $_SESSION['profile'] ?? [
    'first_name' => 'Madam',
    'last_name' => 'Glorious',
    'email' => 'customer@example.com',
];

$message = '';
$error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Password Change Logic
    if (isset($_POST['action']) && $_POST['action'] === 'change_password') {
        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
            $error = "Please fill in all password fields.";
        } elseif ($newPassword !== $confirmPassword) {
            $error = "New password and confirm password do not match.";
        } elseif (strlen($newPassword) < 6) {
            $error = "New password must be at least 6 characters long.";
        } else {
            $message = "Your password has been updated successfully!";
        }
    }

    // Notification Settings Logic
    if (isset($_POST['action']) && $_POST['action'] === 'update_notifications') {
        $_SESSION['notifications'] = [
            'email_orders' => isset($_POST['email_orders']),
            'email_promos' => isset($_POST['email_promos']),
            'sms_updates' => isset($_POST['sms_updates']),
        ];
        $message = "Your notification preferences have been saved!";
    }
}

$notifications = $_SESSION['notifications'] ?? [
    'email_orders' => true,
    'email_promos' => false,
    'sms_updates' => true,
];

function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

ob_start();
?>

<!-- PAGE HEADER -->
<section class="page-head">
    <div class="container">
        <h1>Account Settings</h1>
        <div class="breadcrumb justify-content-center">
            <a href="index.php">Home</a> &nbsp;/&nbsp; <a href="profile.php">My Account</a> &nbsp;/&nbsp;
            <span>Settings</span>
        </div>
    </div>
</section>

<!-- MAIN DASHBOARD LAYOUT -->
<section class="section mg-dashboard">
    <div class="container">
        <div class="mg-dashboard-layout">

            <!-- SIDEBAR -->
            <aside class="mg-account-sidebar">
                <div class="mg-profile-summary">
                    <div class="mg-profile-icon">
                        <i class="bi bi-person"></i>
                    </div>
                    <h3><?= e(trim(($profile['first_name'] ?? 'Madam') . ' ' . ($profile['last_name'] ?? 'Glorious'))) ?>
                    </h3>
                    <p><?= e($profile['email'] ?? 'customer@example.com') ?></p>
                </div>

                <nav class="mg-account-menu">
                    <a href="dashboard.php" class="mg-menu-link">
                        <i class="bi bi-grid"></i> <span>Dashboard</span>
                    </a>
                    <a href="order.php" class="mg-menu-link">
                        <i class="bi bi-bag"></i> <span>My Orders</span>
                    </a>
                    <a href="profile.php" class="mg-menu-link">
                        <i class="bi bi-person"></i> <span>My Profile</span>
                    </a>
                    <a href="wishlist.php" class="mg-menu-link">
                        <i class="bi bi-heart"></i> <span>Wishlist</span>
                    </a>
                    <a href="addresses.php" class="mg-menu-link">
                        <i class="bi bi-geo-alt"></i> <span>Addresses</span>
                    </a>
                    <a href="settings.php" class="mg-menu-link active">
                        <i class="bi bi-gear"></i> <span>Account Settings</span>
                    </a>
                    <a href="logout.php" class="mg-menu-link mg-logout">
                        <i class="bi bi-box-arrow-right"></i> <span>Logout</span>
                    </a>
                </nav>
            </aside>

            <!-- MAIN CONTENT AREA -->
            <div class="mg-dashboard-main">

                <?php if ($message !== ''): ?>
                    <div class="notice mb-4" style="background:#e8f4e7; border-color:#b8e0b5; color:#287b38;">
                        <?= e($message) ?>
                    </div>
                <?php endif; ?>

                <?php if ($error !== ''): ?>
                    <div class="notice mb-4" style="background:#fde8e8; border-color:#f8b4b4; color:#9b1c1c;">
                        <?= e($error) ?>
                    </div>
                <?php endif; ?>

                <!-- CHANGE PASSWORD FORM -->
                <div class="form-wrap w-100 max-width-none mb-5">
                    <div class="border-bottom pb-2 mb-4">
                        <h3 class="fs-4 font-serif m-0"><i class="bi bi-shield-lock text-pink me-2"></i> Change Password
                        </h3>
                        <small class="text-muted">Update your password regularly to keep your account secure.</small>
                    </div>

                    <form method="post" action="settings.php">
                        <input type="hidden" name="action" value="change_password">

                        <div class="form-group mb-3">
                            <label for="current_password">Current Password</label>
                            <input type="password" id="current_password" name="current_password" class="form-control"
                                placeholder="Enter current password" required>
                        </div>

                        <div class="two-col">
                            <div class="form-group">
                                <label for="new_password">New Password</label>
                                <input type="password" id="new_password" name="new_password" class="form-control"
                                    placeholder="Enter new password" required>
                            </div>
                            <div class="form-group">
                                <label for="confirm_password">Confirm New Password</label>
                                <input type="password" id="confirm_password" name="confirm_password"
                                    class="form-control" placeholder="Re-enter new password" required>
                            </div>
                        </div>

                        <button type="submit" class="btn px-4 mt-3">UPDATE PASSWORD</button>
                    </form>
                </div>

                <!-- NOTIFICATION PREFERENCES -->
                <div class="form-wrap w-100 max-width-none mb-5">
                    <div class="border-bottom pb-2 mb-4">
                        <h3 class="fs-4 font-serif m-0"><i class="bi bi-bell text-pink me-2"></i> Notification
                            Preferences</h3>
                        <small class="text-muted">Choose the type of updates you would like to receive.</small>
                    </div>

                    <form method="post" action="settings.php">
                        <input type="hidden" name="action" value="update_notifications">

                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" id="email_orders" name="email_orders"
                                <?= $notifications['email_orders'] ? 'checked' : '' ?>>
                            <label class="form-check-label fw-bold" for="email_orders">
                                Order & Delivery Updates
                            </label>
                            <div class="text-muted small">Receive order confirmation, shipping, and delivery tracking
                                emails.</div>
                        </div>

                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" id="email_promos" name="email_promos"
                                <?= $notifications['email_promos'] ? 'checked' : '' ?>>
                            <label class="form-check-label fw-bold" for="email_promos">
                                Offers & Promotions
                            </label>
                            <div class="text-muted small">Get updates on new arrivals, sale offers, and discount
                                coupons.</div>
                        </div>

                        <div class="form-check mb-4">
                            <input class="form-check-input" type="checkbox" id="sms_updates" name="sms_updates"
                                <?= $notifications['sms_updates'] ? 'checked' : '' ?>>
                            <label class="form-check-label fw-bold" for="sms_updates">
                                SMS & WhatsApp Alerts
                            </label>
                            <div class="text-muted small">Receive instant delivery alerts on your mobile.</div>
                        </div>

                        <button type="submit" class="btn px-4">SAVE PREFERENCES</button>
                    </form>
                </div>

                <!-- DANGER ZONE / ACCOUNT DELETE -->
                <div class="form-wrap w-100 max-width-none border-danger">
                    <div class="border-bottom pb-2 mb-3">
                        <h3 class="fs-4 font-serif text-danger m-0"><i class="bi bi-exclamation-triangle me-2"></i>
                            Account Danger Zone</h3>
                    </div>
                    <p class="text-muted fs-6 mb-3">If you wish to permanently delete your account, click the button
                        below. This action cannot be undone.</p>
                    <a href="delete-account.php" class="btn btn-sm" style="background: #dc3545; border-color: #dc3545;"
                        onclick="return confirm('Are you sure you want to delete your account?');">
                        <i class="bi bi-trash"></i> DELETE ACCOUNT
                    </a>
                </div>

            </div>
        </div>
    </div>
</section>

<?php
$content = ob_get_clean();
include 'layout.php';
?>