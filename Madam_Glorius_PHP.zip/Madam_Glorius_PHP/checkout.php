<?php
session_start();

// 1. Agar user logged in nahi hai, toh login page par bhejein (Optional)
if (!isset($_SESSION['user_id']) && !isset($_SESSION['profile'])) {
    header("Location: login.php?redirect=checkout.php");
    exit();
}

// 2. Agar cart khali hai, toh user ko shop ya cart page par bhej dein
if (empty($_SESSION['cart'])) {
    header("Location: cart.php");
    exit();
}

// Cart items aur total price Calculate Karein
$cart = $_SESSION['cart'];
$totalPrice = 0;
foreach ($cart as $item) {
    $totalPrice += $item['price'] * $item['quantity'];
}

$pageTitle = "Checkout | Madame Glorious";
ob_start();
?>

<!-- PAGE TITLE -->
<section class="page-head">
    <div class="container">
        <h1>Checkout</h1>
        <div class="breadcrumb justify-content-center">
            <a href="index.php">Home</a> &nbsp;/&nbsp; <a href="cart.php">Cart</a> &nbsp;/&nbsp; <span>Checkout</span>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <form action="place-order.php" method="POST">
            <div class="row g-4">

                <!-- LEFT SIDE: Address & Payment Details -->
                <div class="col-lg-7">
                    <div class="form-wrap w-100 max-width-none mb-4">
                        <h3 class="fs-4 font-serif border-bottom pb-2 mb-3">Shipping Details</h3>

                        <div class="form-group mb-3">
                            <label>Full Name</label>
                            <input type="text" name="name" class="form-control"
                                value="<?= htmlspecialchars($_SESSION['profile']['first_name'] ?? '') ?>" required>
                        </div>

                        <div class="form-group mb-3">
                            <label>Delivery Address</label>
                            <textarea name="address" class="form-control" rows="3" required></textarea>
                        </div>

                        <div class="two-col">
                            <div class="form-group mb-3">
                                <label>Phone</label>
                                <input type="tel" name="phone" class="form-control"
                                    value="<?= htmlspecialchars($_SESSION['profile']['phone'] ?? '') ?>" required>
                            </div>
                            <div class="form-group mb-3">
                                <label>Pincode</label>
                                <input type="text" name="pincode" class="form-control" required>
                            </div>
                        </div>
                    </div>

                    <!-- Payment Options -->
                    <div class="form-wrap w-100 max-width-none">
                        <h3 class="fs-4 font-serif border-bottom pb-2 mb-3">Payment Method</h3>
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="radio" name="payment_mode" id="cod" value="COD"
                                checked>
                            <label class="form-check-label" for="cod">Cash on Delivery (COD)</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="payment_mode" id="online" value="Online">
                            <label class="form-check-label" for="online">Online Payment (UPI / Card /
                                NetBanking)</label>
                        </div>
                    </div>
                </div>

                <!-- RIGHT SIDE: Order Summary Preview -->
                <div class="col-lg-5">
                    <div class="summary border p-4 rounded shadow-sm bg-white">
                        <h3 class="fs-4 font-serif border-bottom pb-2 mb-3">Your Order</h3>

                        <?php foreach ($cart as $item): ?>
                            <div class="d-flex justify-content-between align-items-center mb-2 pb-2 border-bottom">
                                <div>
                                    <strong><?= htmlspecialchars($item['title']) ?></strong>
                                    <br><small class="text-muted">Qty: <?= $item['quantity'] ?></small>
                                </div>
                                <span>₹<?= number_format($item['price'] * $item['quantity'], 2) ?></span>
                            </div>
                        <?php endforeach; ?>

                        <div class="d-flex justify-content-between mt-3 fw-bold fs-5">
                            <span>Total Payable</span>
                            <span class="text-pink">₹<?= number_format($totalPrice, 2) ?></span>
                        </div>

                        <button type="submit" class="btn w-100 mt-4 py-2">PLACE ORDER</button>
                    </div>
                </div>

            </div>
        </form>
    </div>
</section>

<?php
$content = ob_get_clean();
include 'layout.php';
?>